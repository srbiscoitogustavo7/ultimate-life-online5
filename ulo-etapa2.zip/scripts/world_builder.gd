extends Node3D
# Constrói um mundo de teste: céu, sol, chão, ruas, prédios, rampa e plataformas.
# (A cidade completa vem na Etapa 2.)


func build() -> void:
	_add_environment()
	_add_ground()
	_add_roads()
	_add_sidewalks()
	_add_crosswalks()
	_add_buildings()
	_add_test_obstacles()


func _add_environment() -> void:
	var sky_material := ProceduralSkyMaterial.new()
	var sky := Sky.new()
	sky.sky_material = sky_material

	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY

	var world_env := WorldEnvironment.new()
	world_env.environment = env
	add_child(world_env)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -30, 0)
	sun.shadow_enabled = true
	add_child(sun)


func _add_ground() -> void:
	_solid_box(Vector3(0, -0.5, 0), Vector3(600, 1, 600), Color(0.28, 0.5, 0.28), Vector3.ZERO)


func _add_roads() -> void:
	var road_color := Color(0.15, 0.15, 0.17)
	add_child(_mesh_box(Vector3(0, 0.01, 0), Vector3(600, 0.02, 12), road_color))
	add_child(_mesh_box(Vector3(0, 0.01, 0), Vector3(12, 0.02, 600), road_color))


# Calçadas (sólidas, 8 cm de altura) dos dois lados de cada rua, sem cobrir o cruzamento.
func _add_sidewalks() -> void:
	var color := Color(0.62, 0.62, 0.6)
	var side_len: float = 294.0
	var mid: float = 153.0
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			_solid_box(Vector3(sx * mid, 0.04, sz * 7.5), Vector3(side_len, 0.08, 3.0), color, Vector3.ZERO)
			_solid_box(Vector3(sx * 7.5, 0.04, sz * mid), Vector3(3.0, 0.08, side_len), color, Vector3.ZERO)


# Faixas de pedestres nos 4 lados do cruzamento.
func _add_crosswalks() -> void:
	var white := Color(0.9, 0.9, 0.9)
	for i in range(-5, 6):
		var o: float = float(i)
		for s in [-1.0, 1.0]:
			add_child(_mesh_box(Vector3(o, 0.025, s * 7.5), Vector3(0.5, 0.012, 3.0), white))
			add_child(_mesh_box(Vector3(s * 7.5, 0.025, o), Vector3(3.0, 0.012, 0.5), white))


func _add_buildings() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for ix in range(-4, 5):
		for iz in range(-4, 5):
			if ix == 0 or iz == 0:
				continue
			var h: float = rng.randf_range(6.0, 30.0)
			var tone: float = rng.randf_range(0.45, 0.8)
			_solid_box(
				Vector3(ix * 36.0, h / 2.0, iz * 36.0),
				Vector3(20, h, 20),
				Color(tone, tone, tone + 0.05),
				Vector3.ZERO
			)


func _add_test_obstacles() -> void:
	# Rampa que sobe em direção a -Z.
	_solid_box(Vector3(10, 1.3, -12), Vector3(6, 0.5, 12), Color(0.8, 0.6, 0.2), Vector3(15, 0, 0))
	# Plataformas para testar o pulo.
	_solid_box(Vector3(-8, 0.5, -8), Vector3(4, 1.0, 4), Color(0.2, 0.6, 0.8), Vector3.ZERO)
	_solid_box(Vector3(-14, 1.0, -8), Vector3(4, 2.0, 4), Color(0.8, 0.3, 0.5), Vector3.ZERO)


func _solid_box(center: Vector3, size: Vector3, color: Color, rot_deg: Vector3) -> void:
	var body := StaticBody3D.new()
	body.position = center
	body.rotation_degrees = rot_deg
	body.collision_layer = 1

	var shape := CollisionShape3D.new()
	var box_shape := BoxShape3D.new()
	box_shape.size = size
	shape.shape = box_shape
	body.add_child(shape)

	body.add_child(_mesh_box(Vector3.ZERO, size, color))
	add_child(body)


func _mesh_box(center: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = center
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mi.material_override = mat
	return mi
