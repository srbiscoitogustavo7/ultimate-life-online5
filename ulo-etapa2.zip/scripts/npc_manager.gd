extends Node3D
# Cria o grafo de calçadas/faixas de pedestres e os NPCs que andam por ele.

const NpcScript = preload("res://scripts/npc.gd")

const NPC_COUNT: int = 24
const SIDEWALK_OFFSET: float = 7.5
const STEP: float = 30.0
const FAR: float = 120.0

var rng := RandomNumberGenerator.new()
var player = null

var _nodes: Array = []
var _adj: Array = []


func build(player_ref) -> void:
	player = player_ref
	rng.randomize()
	_build_graph()
	_spawn_npcs()


func node_pos(i: int) -> Vector3:
	return _nodes[i] as Vector3


func neighbors(i: int) -> Array:
	return _adj[i] as Array


func get_player_position() -> Vector3:
	if player != null and is_instance_valid(player):
		return player.global_position
	return Vector3.ZERO


func _add_node(p: Vector3) -> int:
	_nodes.append(p)
	_adj.append([])
	return _nodes.size() - 1


func _link(a: int, b: int) -> void:
	_adj[a].append(b)
	_adj[b].append(a)


func _build_graph() -> void:
	var c: float = SIDEWALK_OFFSET
	var corners: Array = [
		_add_node(Vector3(c, 0, c)),
		_add_node(Vector3(-c, 0, c)),
		_add_node(Vector3(-c, 0, -c)),
		_add_node(Vector3(c, 0, -c)),
	]
	# Faixas de pedestres: ligam os 4 cantos do cruzamento.
	for i in 4:
		_link(corners[i] as int, corners[(i + 1) % 4] as int)

	# Calçadas que saem de cada canto, com pontos a cada STEP metros.
	var dirs: Array = [
		[Vector3(1, 0, 0), Vector3(0, 0, 1)],
		[Vector3(-1, 0, 0), Vector3(0, 0, 1)],
		[Vector3(-1, 0, 0), Vector3(0, 0, -1)],
		[Vector3(1, 0, 0), Vector3(0, 0, -1)],
	]
	for i in 4:
		var corner_idx: int = corners[i] as int
		var base: Vector3 = _nodes[corner_idx] as Vector3
		for d in dirs[i]:
			var dir_vec: Vector3 = d as Vector3
			var prev: int = corner_idx
			var dist: float = STEP
			while dist <= FAR:
				var idx: int = _add_node(base + dir_vec * dist)
				_link(prev, idx)
				prev = idx
				dist += STEP


func _spawn_npcs() -> void:
	for i in NPC_COUNT:
		var a: int = rng.randi() % _nodes.size()
		var opts: Array = _adj[a] as Array
		var b: int = opts[rng.randi() % opts.size()] as int
		var npc = NpcScript.new()
		add_child(npc)
		npc.setup(self, a, b, rng.randf())
