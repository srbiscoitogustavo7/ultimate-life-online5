extends AnimatableBody3D
# NPC que anda pelas calçadas seguindo o grafo de pontos do NpcManager.
# Comportamento: anda, às vezes para para "descansar", espera se o jogador estiver na frente.

const HumanoidScript = preload("res://scripts/humanoid.gd")
const GROUND_Y: float = 0.06
const ACTIVE_DISTANCE: float = 70.0

var manager = null

var _human = null
var _speed: float = 1.4
var _prev_node: int = -1
var _to_node: int = 0
var _wait: float = 0.0


func setup(mgr, from_idx: int, to_idx: int, t: float) -> void:
	manager = mgr
	var rng: RandomNumberGenerator = mgr.rng

	sync_to_physics = false
	collision_layer = 4
	collision_mask = 0

	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.3
	cap.height = 1.75
	col.shape = cap
	col.position = Vector3(0, 0.88, 0)
	add_child(col)

	var skins: Array = [
		Color(0.96, 0.80, 0.69), Color(0.87, 0.69, 0.53), Color(0.74, 0.55, 0.39),
		Color(0.55, 0.38, 0.26), Color(0.36, 0.24, 0.17)
	]
	var shirts: Array = [
		Color(0.85, 0.2, 0.2), Color(0.2, 0.5, 0.85), Color(0.2, 0.7, 0.4), Color(0.95, 0.8, 0.2),
		Color(0.9, 0.9, 0.9), Color(0.3, 0.3, 0.35), Color(0.6, 0.3, 0.7), Color(0.95, 0.5, 0.15)
	]
	var pants: Array = [
		Color(0.15, 0.25, 0.5), Color(0.1, 0.1, 0.12), Color(0.4, 0.4, 0.42), Color(0.6, 0.5, 0.35)
	]
	var hairs: Array = [
		Color(0.05, 0.04, 0.04), Color(0.2, 0.12, 0.07), Color(0.4, 0.25, 0.12),
		Color(0.85, 0.7, 0.35), Color(0.6, 0.6, 0.6)
	]

	_human = HumanoidScript.new()
	add_child(_human)
	_human.setup(_pick(skins, rng), _pick(shirts, rng), _pick(pants, rng), _pick(hairs, rng))

	_speed = rng.randf_range(1.1, 1.7)
	_prev_node = from_idx
	_to_node = to_idx

	var a: Vector3 = mgr.node_pos(from_idx)
	var b: Vector3 = mgr.node_pos(to_idx)
	position = a.lerp(b, t)
	position.y = GROUND_Y
	var dir: Vector3 = (b - a).normalized()
	rotation.y = atan2(-dir.x, -dir.z)


func _pick(arr: Array, rng: RandomNumberGenerator) -> Color:
	return arr[rng.randi() % arr.size()] as Color


func _physics_process(delta: float) -> void:
	if manager == null:
		return

	var player_pos: Vector3 = manager.get_player_position()
	var near: bool = (player_pos - position).length_squared() < ACTIVE_DISTANCE * ACTIVE_DISTANCE
	if visible != near:
		visible = near

	var moving_speed: float = 0.0
	if _wait > 0.0:
		_wait -= delta
	else:
		var target: Vector3 = manager.node_pos(_to_node)
		var to_vec: Vector3 = target - position
		to_vec.y = 0.0
		var dist: float = to_vec.length()
		if dist < 0.25:
			_arrive()
		else:
			var dir: Vector3 = to_vec / dist
			var to_player: Vector3 = player_pos - position
			to_player.y = 0.0
			if to_player.length() < 1.6 and to_player.normalized().dot(dir) > 0.4:
				_wait = 0.5
			else:
				position += dir * _speed * delta
				moving_speed = _speed
				var target_yaw: float = atan2(-dir.x, -dir.z)
				rotation.y = lerp_angle(rotation.y, target_yaw, clampf(8.0 * delta, 0.0, 1.0))

	if near:
		_human.animate(delta, moving_speed, false)


func _arrive() -> void:
	var options: Array = manager.neighbors(_to_node)
	var rng: RandomNumberGenerator = manager.rng
	var cands: Array = []
	for n in options:
		if n != _prev_node:
			cands.append(n)
	# Em pontas de calçada (ou às vezes) dá meia-volta.
	if cands.is_empty() or rng.randf() < 0.12:
		cands = options.duplicate()

	var next_node: int = _to_node
	if cands.size() > 0:
		next_node = cands[rng.randi() % cands.size()] as int

	_prev_node = _to_node
	_to_node = next_node

	if rng.randf() < 0.2:
		_wait = rng.randf_range(1.5, 4.0)
