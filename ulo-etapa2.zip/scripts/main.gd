extends Node3D
# Cena principal: monta o mundo, o jogador, os controles de toque e o HUD.

const WorldBuilderScript = preload("res://scripts/world_builder.gd")
const PlayerScript = preload("res://scripts/player.gd")
const TouchControlsScript = preload("res://scripts/touch_controls.gd")
const NpcManagerScript = preload("res://scripts/npc_manager.gd")

var _fps_label: Label


func _ready() -> void:
	Engine.max_fps = 60

	var world = WorldBuilderScript.new()
	add_child(world)
	world.build()

	var ui := CanvasLayer.new()
	add_child(ui)

	var controls = TouchControlsScript.new()
	ui.add_child(controls)

	_fps_label = Label.new()
	_fps_label.position = Vector2(24, 16)
	_fps_label.add_theme_font_size_override("font_size", 26)
	_fps_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	_fps_label.add_theme_constant_override("outline_size", 6)
	ui.add_child(_fps_label)

	var player = PlayerScript.new()
	player.controls = controls
	player.position = player.spawn_point
	add_child(player)

	var npcs = NpcManagerScript.new()
	add_child(npcs)
	npcs.build(player)


func _process(_delta: float) -> void:
	_fps_label.text = "ULTIMATE LIFE ONLINE | Etapa 2 | FPS: %d" % Engine.get_frames_per_second()
