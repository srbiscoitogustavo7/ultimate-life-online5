# Ultimate Life Online (Godot 4.3)

## Etapa 1
Estrutura do projeto e personagem controlável (joystick, correr, pular, câmera por toque).

## Etapa 2 (esta versão)
- Personagem humano 3D (procedural, peças simples) com animação de andar, correr e pular.
- 24 NPCs humanos andando pelas calçadas, atravessando nas faixas de pedestres,
  parando às vezes e esperando se o jogador estiver na frente deles.
- Ruas com calçadas e faixas de pedestres.
- NPCs distantes (mais de 70 m) ficam ocultos para economizar desempenho.

## Ainda NÃO existe
Carros, concessionárias, detalhes do mapa, semáforos, reações dos NPCs, polícia, economia, multiplayer.

## Estrutura
scripts/humanoid.gd (corpo e animação) | npc.gd (comportamento) | npc_manager.gd (calçadas e spawn)
world_builder.gd (mundo) | player.gd | touch_controls.gd | main.gd
