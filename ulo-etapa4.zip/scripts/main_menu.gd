extends Control
# Menu inicial com a capa do jogo: JOGAR, GRÁFICOS e SAIR.

signal play_pressed
signal quit_pressed

const COVER_PATH: String = "res://assets/cover.png"
const SettingsUIScript = preload("res://scripts/ui_settings.gd")

var _settings_ui = null


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)

	var bg := ColorRect.new()
	bg.color = Color(0.03, 0.04, 0.08)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	if ResourceLoader.exists(COVER_PATH):
		var tex := load(COVER_PATH) as Texture2D
		if tex != null:
			var cover := TextureRect.new()
			cover.texture = tex
			cover.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			cover.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
			cover.set_anchors_preset(Control.PRESET_FULL_RECT)
			add_child(cover)

	var strip := ColorRect.new()
	strip.color = Color(0, 0, 0, 0.75)
	strip.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	strip.offset_top = -150.0
	add_child(strip)

	var row := HBoxContainer.new()
	row.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	row.offset_top = -130.0
	row.offset_bottom = -20.0
	row.offset_left = 40.0
	row.offset_right = -40.0
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 24)
	add_child(row)

	row.add_child(_button("JOGAR", Color(0.95, 0.75, 0.1), Color.BLACK, _on_play))
	row.add_child(_button("GRÁFICOS", Color(0.15, 0.55, 0.95), Color.WHITE, _on_graphics))
	row.add_child(_button("SAIR", Color(0.7, 0.15, 0.15), Color.WHITE, _on_quit))

	var ver := Label.new()
	ver.text = "v0.3 - Etapa 3"
	ver.add_theme_font_size_override("font_size", 22)
	ver.add_theme_color_override("font_outline_color", Color.BLACK)
	ver.add_theme_constant_override("outline_size", 6)
	ver.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	ver.offset_left = -260.0
	ver.offset_top = 12.0
	add_child(ver)


func _button(text: String, bg: Color, fg: Color, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(340, 90)
	b.add_theme_font_size_override("font_size", 34)
	for state in ["normal", "hover", "pressed"]:
		var sb := StyleBoxFlat.new()
		var shade: float = 1.0
		if str(state) == "pressed":
			shade = 0.75
		sb.bg_color = Color(bg.r * shade, bg.g * shade, bg.b * shade)
		sb.set_corner_radius_all(18)
		b.add_theme_stylebox_override(str(state), sb)
	b.add_theme_color_override("font_color", fg)
	b.add_theme_color_override("font_hover_color", fg)
	b.add_theme_color_override("font_pressed_color", fg)
	b.pressed.connect(cb)
	return b


func _on_play() -> void:
	play_pressed.emit()


func _on_quit() -> void:
	quit_pressed.emit()


func _on_graphics() -> void:
	if _settings_ui != null:
		return
	_settings_ui = SettingsUIScript.new()
	add_child(_settings_ui)
	_settings_ui.closed.connect(_on_graphics_closed)


func _on_graphics_closed() -> void:
	if _settings_ui != null:
		_settings_ui.queue_free()
		_settings_ui = null
