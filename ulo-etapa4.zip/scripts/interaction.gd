extends Node
# Detecta o ponto de interação (porta de loja / central de empregos) mais próximo do jogador.

signal activated(entry)

const ShopsData = preload("res://scripts/shops_data.gd")
const RANGE: float = 5.0

var nearest: Dictionary = {}

var _player = null
var _list: Array = []
var _accum: float = 0.0


func setup(player) -> void:
	_player = player
	_list = ShopsData.interactables()


func _process(delta: float) -> void:
	if _player == null:
		return
	_accum += delta
	if _accum < 0.15:
		return
	_accum = 0.0

	var pp: Vector3 = _player.global_position
	var best: Dictionary = {}
	var best_d: float = RANGE
	for e in _list:
		var entry: Dictionary = e
		var p: Vector3 = entry["pos"]
		var d: float = Vector2(p.x - pp.x, p.z - pp.z).length()
		if d < best_d:
			best_d = d
			best = entry
	nearest = best


func activate() -> void:
	if not nearest.is_empty():
		activated.emit(nearest)
