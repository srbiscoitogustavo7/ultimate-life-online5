extends Node3D
# Trabalhos. Disponível agora: Entregador (a pé). Os demais dependem de veículos (próxima etapa).

const CityGen = preload("res://scripts/city_gen.gd")
const ShopsData = preload("res://scripts/shops_data.gd")

var active: String = ""
var objective_text: String = ""
var message: String = ""

var _player = null
var _economy = null
var _target: Vector3 = Vector3.ZERO
var _marker: Node3D = null
var _label: Label3D = null
var _time_left: float = 0.0
var _pay: int = 0
var _msg_time: float = 0.0
var _rng := RandomNumberGenerator.new()


func setup(player, economy) -> void:
	_player = player
	_economy = economy
	_rng.randomize()


func start_job(id: String) -> void:
	if id != "entregador_pe":
		return
	active = id
	message = "Trabalho iniciado: Entregador. Siga o feixe amarelo!"
	_msg_time = 6.0
	_new_delivery()


func stop_job() -> void:
	active = ""
	objective_text = ""
	message = "Trabalho encerrado."
	_msg_time = 4.0
	_clear_marker()


func _new_delivery() -> void:
	var pp: Vector3 = _player.global_position
	var h: int = CityGen.HALF
	_target = CityGen.corner_pos(Vector4i(1, 1, 1, 1))
	for attempt in 20:
		var angle: float = _rng.randf() * TAU
		var dist: float = _rng.randf_range(180.0, 500.0)
		var gx: int = int(round((pp.x + cos(angle) * dist) / CityGen.CHUNK))
		var gz: int = int(round((pp.z + sin(angle) * dist) / CityGen.CHUNK))
		gx = clampi(gx, -h + 1, h - 1)
		gz = clampi(gz, -h + 1, h - 1)
		var sx: int = 1
		if _rng.randf() < 0.5:
			sx = -1
		var sz: int = 1
		if _rng.randf() < 0.5:
			sz = -1
		var t: Vector3 = CityGen.corner_pos(Vector4i(gx, gz, sx, sz))
		var d: float = Vector2(t.x - pp.x, t.z - pp.z).length()
		if d >= 120.0:
			_target = t
			break
	var total: float = Vector2(_target.x - pp.x, _target.z - pp.z).length()
	_time_left = total / 4.0 + 30.0
	_pay = 80 + int(total * 0.25)
	_create_marker()


func _create_marker() -> void:
	_clear_marker()
	_marker = Node3D.new()
	_marker.position = _target
	add_child(_marker)

	var beam := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.0
	cm.bottom_radius = 1.0
	cm.height = 150.0
	cm.radial_segments = 12
	cm.rings = 1
	beam.mesh = cm
	beam.position = Vector3(0, 75, 0)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color(1.0, 0.85, 0.1, 0.35)
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	beam.material_override = mat
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_marker.add_child(beam)

	_label = Label3D.new()
	_label.font_size = 64
	_label.pixel_size = 0.02
	_label.outline_size = 12
	_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_label.no_depth_test = true
	_label.position = Vector3(0, 9, 0)
	_marker.add_child(_label)


func _clear_marker() -> void:
	if _marker != null:
		_marker.queue_free()
		_marker = null
		_label = null


func _process(delta: float) -> void:
	if _msg_time > 0.0:
		_msg_time -= delta
		if _msg_time <= 0.0:
			message = ""

	if active == "" or _player == null:
		return

	_time_left -= delta
	var pp: Vector3 = _player.global_position
	var d: float = Vector2(_target.x - pp.x, _target.z - pp.z).length()
	if _label != null:
		_label.text = "ENTREGA\n%d m" % int(d)
	objective_text = "ENTREGA: %d m  |  tempo: %d s  |  ganho: %s" % [int(d), int(maxf(_time_left, 0.0)), ShopsData.fmt(_pay)]

	if d < 4.0:
		_economy.add_money(_pay)
		_economy.deliveries_done += 1
		message = "Entrega concluída! +" + ShopsData.fmt(_pay)
		_msg_time = 5.0
		_new_delivery()
	elif _time_left <= 0.0:
		message = "Tempo esgotado! Nova entrega."
		_msg_time = 5.0
		_new_delivery()
