extends Control
# Painel de loja (comprar itens) ou da Central de Empregos (iniciar/encerrar trabalho).

signal closed
signal job_selected(job_id: String)
signal job_stopped

const ShopsData = preload("res://scripts/shops_data.gd")

var _economy = null
var _jobs = null
var _money_label: Label
var _msg_label: Label
var _stuff_label: Label


func setup(entry: Dictionary, economy, jobs) -> void:
	_economy = economy
	_jobs = jobs
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)

	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.03, 0.06, 0.96)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + str(side), 28)
	add_child(margin)

	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 12)
	margin.add_child(root)

	var title := Label.new()
	title.text = str(entry["name"]).to_upper()
	title.add_theme_font_size_override("font_size", 38)
	root.add_child(title)

	_money_label = Label.new()
	_money_label.add_theme_font_size_override("font_size", 26)
	root.add_child(_money_label)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(scroll)

	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 8)
	scroll.add_child(list)

	if str(entry["kind"]) == "jobs":
		_build_jobs(list)
	else:
		_build_items(list, str(entry["id"]))

	_msg_label = Label.new()
	_msg_label.add_theme_font_size_override("font_size", 24)
	_msg_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(_msg_label)

	_stuff_label = Label.new()
	_stuff_label.add_theme_font_size_override("font_size", 20)
	_stuff_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(_stuff_label)

	var close := Button.new()
	close.text = "FECHAR"
	close.custom_minimum_size = Vector2(0, 80)
	close.add_theme_font_size_override("font_size", 32)
	close.pressed.connect(_on_close)
	root.add_child(close)

	_refresh()


func _build_items(list: VBoxContainer, shop_id: String) -> void:
	for it in ShopsData.catalog(shop_id):
		var item: Dictionary = it
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)

		var label := Label.new()
		label.text = "%s\n%s" % [str(item["name"]), ShopsData.fmt(int(item["price"]))]
		label.add_theme_font_size_override("font_size", 26)
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		row.add_child(label)

		var btn := Button.new()
		btn.text = "COMPRAR"
		btn.custom_minimum_size = Vector2(240, 76)
		btn.add_theme_font_size_override("font_size", 26)
		btn.pressed.connect(_on_buy.bind(item))
		row.add_child(btn)

		list.add_child(row)
		list.add_child(HSeparator.new())


func _build_jobs(list: VBoxContainer) -> void:
	if _jobs != null and _jobs.active != "":
		var stop := Button.new()
		stop.text = "ENCERRAR TRABALHO ATUAL"
		stop.custom_minimum_size = Vector2(0, 76)
		stop.add_theme_font_size_override("font_size", 26)
		stop.pressed.connect(_on_stop)
		list.add_child(stop)

	for j in ShopsData.jobs():
		var job: Dictionary = j
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)

		var label := Label.new()
		label.text = "%s\n%s" % [str(job["name"]), str(job["desc"])]
		label.add_theme_font_size_override("font_size", 24)
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		row.add_child(label)

		var btn := Button.new()
		btn.custom_minimum_size = Vector2(240, 76)
		btn.add_theme_font_size_override("font_size", 26)
		if bool(job["available"]):
			btn.text = "INICIAR"
			btn.pressed.connect(_on_job.bind(str(job["id"])))
		else:
			btn.text = "EM BREVE"
			btn.disabled = true
		row.add_child(btn)

		list.add_child(row)
		list.add_child(HSeparator.new())


func _on_buy(item: Dictionary) -> void:
	_msg_label.text = str(_economy.buy(item))
	_refresh()


func _on_job(id: String) -> void:
	job_selected.emit(id)


func _on_stop() -> void:
	job_stopped.emit()


func _on_close() -> void:
	closed.emit()


func _refresh() -> void:
	var fome: String = "%d%%" % int(_economy.hunger)
	_money_label.text = "Dinheiro: " + ShopsData.fmt(int(_economy.money)) + "     Fome: " + fome
	_stuff_label.text = str(_economy.summary())
