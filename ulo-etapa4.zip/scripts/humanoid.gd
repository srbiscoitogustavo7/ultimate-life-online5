extends Node3D
# Humano 3D procedural (peças simples, sem arquivos externos) com animação de caminhada.
# Usado pelo jogador e pelos NPCs. O personagem olha para -Z.

static var _mesh_cache: Dictionary = {}
static var _mat_cache: Dictionary = {}

var _phase: float = 0.0
var _amp: float = 0.0
var _body: Node3D
var _arm_l: Node3D
var _arm_r: Node3D
var _leg_l: Node3D
var _leg_r: Node3D


static func _material(color: Color) -> StandardMaterial3D:
	var key: String = color.to_html(false)
	if not _mat_cache.has(key):
		var m := StandardMaterial3D.new()
		m.albedo_color = color
		m.roughness = 0.9
		_mat_cache[key] = m
	return _mat_cache[key] as StandardMaterial3D


static func _box_mesh(size: Vector3) -> BoxMesh:
	var key: String = "b" + str(size)
	if not _mesh_cache.has(key):
		var m := BoxMesh.new()
		m.size = size
		_mesh_cache[key] = m
	return _mesh_cache[key] as BoxMesh


static func _sphere_mesh(radius: float, height: float) -> SphereMesh:
	var key: String = "s" + str(radius) + "_" + str(height)
	if not _mesh_cache.has(key):
		var m := SphereMesh.new()
		m.radius = radius
		m.height = height
		m.radial_segments = 10
		m.rings = 5
		_mesh_cache[key] = m
	return _mesh_cache[key] as SphereMesh


func _add_mesh(parent: Node3D, mesh: Mesh, color: Color, pos: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = _material(color)
	mi.position = pos
	parent.add_child(mi)
	return mi


func setup(skin: Color, shirt: Color, pants: Color, hair: Color) -> void:
	var shoe: Color = Color(0.08, 0.08, 0.1)
	var eye: Color = Color(0.05, 0.05, 0.06)

	_body = Node3D.new()
	add_child(_body)

	# tronco, pélvis, pescoço, cabeça, cabelo e olhos
	_add_mesh(_body, _box_mesh(Vector3(0.46, 0.58, 0.24)), shirt, Vector3(0, 1.21, 0))
	_add_mesh(_body, _box_mesh(Vector3(0.44, 0.2, 0.23)), pants, Vector3(0, 0.86, 0))
	_add_mesh(_body, _box_mesh(Vector3(0.1, 0.1, 0.1)), skin, Vector3(0, 1.53, 0))
	_add_mesh(_body, _sphere_mesh(0.12, 0.27), skin, Vector3(0, 1.66, 0))
	_add_mesh(_body, _sphere_mesh(0.13, 0.17), hair, Vector3(0, 1.73, 0.02))
	_add_mesh(_body, _box_mesh(Vector3(0.035, 0.03, 0.02)), eye, Vector3(-0.045, 1.67, -0.115))
	_add_mesh(_body, _box_mesh(Vector3(0.035, 0.03, 0.02)), eye, Vector3(0.045, 1.67, -0.115))

	_leg_l = _make_leg(-0.11, pants, shoe)
	_leg_r = _make_leg(0.11, pants, shoe)
	_arm_l = _make_arm(-0.3, shirt, skin)
	_arm_r = _make_arm(0.3, shirt, skin)


func _make_leg(x: float, pants: Color, shoe: Color) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = Vector3(x, 0.86, 0)
	add_child(pivot)
	_add_mesh(pivot, _box_mesh(Vector3(0.17, 0.78, 0.2)), pants, Vector3(0, -0.39, 0))
	_add_mesh(pivot, _box_mesh(Vector3(0.18, 0.08, 0.28)), shoe, Vector3(0, -0.82, -0.04))
	return pivot


func _make_arm(x: float, shirt: Color, skin: Color) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = Vector3(x, 1.45, 0)
	_body.add_child(pivot)
	_add_mesh(pivot, _box_mesh(Vector3(0.12, 0.3, 0.13)), shirt, Vector3(0, -0.15, 0))
	_add_mesh(pivot, _box_mesh(Vector3(0.1, 0.3, 0.11)), skin, Vector3(0, -0.45, 0))
	return pivot


# speed: velocidade horizontal em m/s. airborne: no ar (pulando/caindo).
func animate(delta: float, speed: float, airborne: bool) -> void:
	var target_amp: float = clampf(speed * 0.3, 0.0, 0.95)
	_amp = lerpf(_amp, target_amp, clampf(10.0 * delta, 0.0, 1.0))
	_phase += delta * (4.0 + speed * 1.1)

	if airborne:
		_leg_l.rotation.x = 0.5
		_leg_r.rotation.x = -0.3
		_arm_l.rotation.x = -0.7
		_arm_r.rotation.x = -0.7
		_body.position.y = 0.0
		return

	var s: float = sin(_phase) * _amp
	_leg_l.rotation.x = s
	_leg_r.rotation.x = -s
	_arm_l.rotation.x = -s * 0.9
	_arm_r.rotation.x = s * 0.9
	_body.position.y = absf(sin(_phase)) * 0.04 * _amp
