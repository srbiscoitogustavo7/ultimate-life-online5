extends Node3D
# População de pedestres que acompanha o jogador pelo mapa gigante.
# Os NPCs andam numa grade de calçadas "implícita" (sem precisar carregar o mapa todo):
# cada canto de cruzamento é (linha i, linha j, lado x, lado z). Quantidade vem das configurações.

const NpcScript = preload("res://scripts/npc.gd")
const CityGen = preload("res://scripts/city_gen.gd")

const SPAWN_MIN: float = 40.0

var rng := RandomNumberGenerator.new()
var player = null

var _npcs: Array = []


func build(player_ref) -> void:
	player = player_ref
	rng.randomize()
	GameSettings.changed.connect(_on_settings)
	_on_settings()


func get_player_position() -> Vector3:
	if player != null and is_instance_valid(player):
		return player.global_position
	return Vector3.ZERO


func cull_radius() -> float:
	return 140.0 + float(GameSettings.current["view_chunks"]) * 40.0


func _on_settings() -> void:
	var target: int = int(GameSettings.current["npc_count"])
	while _npcs.size() < target:
		var npc = NpcScript.new()
		add_child(npc)
		npc.setup(self)
		place_npc(npc)
		_npcs.append(npc)
	while _npcs.size() > target:
		var last = _npcs.pop_back()
		(last as Node).queue_free()


func _valid(c: Vector4i) -> bool:
	var h: int = CityGen.HALF
	if c.x < -h or c.x > h or c.y < -h or c.y > h:
		return false
	if c.x == -h and c.z < 0:
		return false
	if c.x == h and c.z > 0:
		return false
	if c.y == -h and c.w < 0:
		return false
	if c.y == h and c.w > 0:
		return false
	return true


# Próximo canto de calçada: atravessar a rua (faixa de pedestres) ou seguir pela calçada.
func pick_next(cur: Vector4i, prev: Vector4i) -> Vector4i:
	var list: Array = [
		[Vector4i(cur.x, cur.y, -cur.z, cur.w), 0.18],
		[Vector4i(cur.x, cur.y, cur.z, -cur.w), 0.18],
		[Vector4i(cur.x + cur.z, cur.y, -cur.z, cur.w), 0.32],
		[Vector4i(cur.x, cur.y + cur.w, cur.z, -cur.w), 0.32],
	]
	var cands: Array = []
	var weights: Array = []
	var total: float = 0.0
	for e in list:
		var entry: Array = e
		var c: Vector4i = entry[0]
		if c == prev or not _valid(c):
			continue
		cands.append(c)
		weights.append(float(entry[1]))
		total += float(entry[1])
	if cands.is_empty():
		return prev
	var r: float = rng.randf() * total
	for i in cands.size():
		r -= float(weights[i])
		if r <= 0.0:
			return cands[i] as Vector4i
	return cands[cands.size() - 1] as Vector4i


# Escolhe um ponto de calçada perto do jogador (fora da vista imediata) para o NPC.
func place_npc(npc) -> void:
	var pp: Vector3 = get_player_position()
	var radius: float = cull_radius()
	var gi: int = int(round(pp.x / CityGen.CHUNK))
	var gj: int = int(round(pp.z / CityGen.CHUNK))
	var span: int = int(radius / CityGen.CHUNK) + 1

	for attempt in 30:
		var sx: int = 1
		if rng.randf() < 0.5:
			sx = -1
		var sz: int = 1
		if rng.randf() < 0.5:
			sz = -1
		var c := Vector4i(gi + rng.randi_range(-span, span), gj + rng.randi_range(-span, span), sx, sz)
		if not _valid(c):
			continue
		var to_c: Vector4i = pick_next(c, Vector4i(999, 999, 0, 0))
		var a: Vector3 = CityGen.corner_pos(c)
		var b: Vector3 = CityGen.corner_pos(to_c)
		var p: Vector3 = a.lerp(b, rng.randf())
		var dist: float = Vector2(p.x - pp.x, p.z - pp.z).length()
		if attempt < 24 and (dist < SPAWN_MIN or dist > radius):
			continue
		npc.place(c, to_c, p)
		return
