extends Control
# Tela de configurações gráficas: 8 predefinições + cada opção individual + hora do dia.
# Funciona no menu inicial e dentro do jogo (pausando o jogo).

signal closed

var _preset_buttons: Array = []
var _value_buttons: Dictionary = {}
var _time_button: Button
var _title: Label


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)

	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.03, 0.06, 0.96)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + str(side), 28)
	add_child(margin)

	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 14)
	margin.add_child(root)

	_title = Label.new()
	_title.add_theme_font_size_override("font_size", 38)
	root.add_child(_title)

	var hint := Label.new()
	hint.text = "Toque numa predefinição para aplicar tudo de uma vez, ou toque em cada opção para mudar só ela."
	hint.add_theme_font_size_override("font_size", 22)
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(hint)

	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	for i in GameSettings.PRESET_NAMES.size():
		var b := _make_button(str(GameSettings.PRESET_NAMES[i]), 26)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(_on_preset.bind(i))
		grid.add_child(b)
		_preset_buttons.append(b)
	root.add_child(grid)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(scroll)

	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 8)
	scroll.add_child(list)

	for opt in GameSettings.OPTIONS:
		var o: Dictionary = opt
		var key: String = o["key"]
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		var label := Label.new()
		label.text = str(o["label"])
		label.add_theme_font_size_override("font_size", 26)
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(label)
		var btn := _make_button("", 26)
		btn.custom_minimum_size = Vector2(420, 64)
		btn.pressed.connect(_on_cycle.bind(key))
		row.add_child(btn)
		list.add_child(row)
		_value_buttons[key] = btn

	var time_row := HBoxContainer.new()
	time_row.add_theme_constant_override("separation", 12)
	var time_label := Label.new()
	time_label.text = "Hora do dia"
	time_label.add_theme_font_size_override("font_size", 26)
	time_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	time_row.add_child(time_label)
	_time_button = _make_button("", 26)
	_time_button.custom_minimum_size = Vector2(420, 64)
	_time_button.pressed.connect(_on_time)
	time_row.add_child(_time_button)
	list.add_child(time_row)

	var close := _make_button("FECHAR", 32)
	close.custom_minimum_size = Vector2(0, 80)
	close.pressed.connect(_on_close)
	root.add_child(close)

	GameSettings.changed.connect(_refresh)
	_refresh()


func _make_button(text: String, font_size: int) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 64)
	b.add_theme_font_size_override("font_size", font_size)
	return b


func _on_preset(i: int) -> void:
	GameSettings.apply_preset(i)


func _on_cycle(key: String) -> void:
	GameSettings.cycle_option(key, 1)


func _on_time() -> void:
	GameSettings.cycle_time()


func _on_close() -> void:
	closed.emit()


func _refresh() -> void:
	_title.text = "CONFIGURAÇÕES GRÁFICAS - " + GameSettings.preset_name().to_upper()
	for i in _preset_buttons.size():
		var b: Button = _preset_buttons[i]
		if i == GameSettings.preset_index:
			b.modulate = Color(1.0, 0.85, 0.2)
		else:
			b.modulate = Color(1, 1, 1)
	for opt in GameSettings.OPTIONS:
		var o: Dictionary = opt
		var key: String = o["key"]
		var btn: Button = _value_buttons[key]
		btn.text = GameSettings.format_value(str(o["fmt"]), GameSettings.current[key])
	_time_button.text = str(GameSettings.TIME_NAMES[GameSettings.time_mode])
