extends RefCounted
# Lojas e empregos da praça. Nomes e produtos são reais; os preços (R$) são valores de
# referência aproximados para o jogo. Para mudar produtos, edite as listas abaixo.

const PLAZA_CENTER: Vector2 = Vector2(60.0, 60.0)


static func fmt(n: int) -> String:
	var s: String = str(absi(n))
	var out: String = ""
	var count: int = 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		count += 1
		if count % 3 == 0 and i > 0:
			out = "." + out
	if n < 0:
		out = "-" + out
	return "R$ " + out


static func kiosks() -> Array:
	return [
		{"id": "concessionaria", "kind": "shop", "name": "Concessionária", "pos": Vector2(28.0, 24.0), "color": Color(0.15, 0.35, 0.7)},
		{"id": "celulares", "kind": "shop", "name": "Loja de Celulares", "pos": Vector2(60.0, 20.0), "color": Color(0.2, 0.2, 0.25)},
		{"id": "supermercado", "kind": "shop", "name": "Supermercado", "pos": Vector2(92.0, 24.0), "color": Color(0.8, 0.25, 0.2)},
		{"id": "fastfood", "kind": "shop", "name": "Fast Food", "pos": Vector2(28.0, 96.0), "color": Color(0.95, 0.7, 0.1)},
		{"id": "roupas", "kind": "shop", "name": "Loja de Roupas", "pos": Vector2(60.0, 100.0), "color": Color(0.55, 0.25, 0.6)},
		{"id": "empregos", "kind": "jobs", "name": "Central de Empregos", "pos": Vector2(92.0, 96.0), "color": Color(0.15, 0.55, 0.35)},
	]


# Direção da frente da barraca: de frente para o centro da praça.
static func yaw_for(pos: Vector2) -> float:
	var dir: Vector2 = (PLAZA_CENTER - pos).normalized()
	return atan2(-dir.x, -dir.y)


# Pontos de interação (porta de cada barraca) em coordenadas do mundo.
# A praça é o chunk (0, 0), cuja origem é (0, 0).
static func interactables() -> Array:
	var out: Array = []
	for k in kiosks():
		var kd: Dictionary = k
		var pos2: Vector2 = kd["pos"]
		var dir: Vector2 = (PLAZA_CENTER - pos2).normalized()
		var door: Vector2 = pos2 + dir * 6.5
		out.append({
			"id": kd["id"],
			"kind": kd["kind"],
			"name": kd["name"],
			"pos": Vector3(door.x, 0.0, door.y),
		})
	return out


static func _item(item_name: String, price: int, cat: String) -> Dictionary:
	return {"name": item_name, "price": price, "cat": cat}


static func _food(item_name: String, price: int, food: int) -> Dictionary:
	return {"name": item_name, "price": price, "cat": "comida", "food": food}


static func _shirt(item_name: String, price: int, color: Color) -> Dictionary:
	return {"name": item_name, "price": price, "cat": "roupa", "shirt": color}


static func _pants(item_name: String, price: int, color: Color) -> Dictionary:
	return {"name": item_name, "price": price, "cat": "roupa", "pants": color}


static func catalog(shop_id: String) -> Array:
	var out: Array = []
	if shop_id == "concessionaria":
		out.append(_item("Fiat Mobi", 72000, "veiculo"))
		out.append(_item("Volkswagen Gol", 88000, "veiculo"))
		out.append(_item("Chevrolet Onix", 95000, "veiculo"))
		out.append(_item("Hyundai HB20", 98000, "veiculo"))
		out.append(_item("Toyota Corolla", 165000, "veiculo"))
		out.append(_item("Honda Civic", 195000, "veiculo"))
		out.append(_item("Jeep Compass", 200000, "veiculo"))
		out.append(_item("Toyota Hilux", 330000, "veiculo"))
		out.append(_item("Ford Mustang GT", 620000, "veiculo"))
		out.append(_item("Porsche 911 Carrera", 1150000, "veiculo"))
		out.append(_item("Honda CG 160 Titan (moto)", 17500, "veiculo"))
		out.append(_item("Yamaha MT-03 (moto)", 31000, "veiculo"))
		out.append(_item("Kawasaki Ninja 400 (moto)", 36000, "veiculo"))
		out.append(_item("BMW R 1250 GS (moto)", 120000, "veiculo"))
		out.append(_item("Scania R 450 (caminhão)", 900000, "veiculo"))
		out.append(_item("Volvo FH 540 (caminhão)", 1100000, "veiculo"))
		out.append(_item("Mercedes-Benz Actros (caminhão)", 1000000, "veiculo"))
		out.append(_item("Marcopolo Paradiso (ônibus)", 1100000, "veiculo"))
	elif shop_id == "celulares":
		out.append(_item("Apple iPhone 15", 5500, "item"))
		out.append(_item("Samsung Galaxy S24", 5000, "item"))
		out.append(_item("Xiaomi Redmi Note 13", 1500, "item"))
		out.append(_item("Motorola Moto G54", 1300, "item"))
		out.append(_item("Apple AirPods Pro", 1900, "item"))
	elif shop_id == "supermercado":
		out.append(_item("Arroz 5 kg", 30, "item"))
		out.append(_item("Feijão 1 kg", 9, "item"))
		out.append(_item("Leite 1 L", 6, "item"))
		out.append(_item("Café Pilão 500 g", 20, "item"))
		out.append(_item("Ovos (dúzia)", 12, "item"))
		out.append(_food("Pão francês (6 un.)", 8, 12))
		out.append(_food("Banana (1 kg)", 7, 12))
		out.append(_food("Coca-Cola 2 L", 11, 4))
		out.append(_food("Guaraná Antarctica 2 L", 9, 4))
	elif shop_id == "fastfood":
		out.append(_food("McDonald's Big Mac", 32, 35))
		out.append(_food("Burger King Whopper", 34, 38))
		out.append(_food("Pizza (fatia)", 12, 15))
		out.append(_food("Coxinha", 8, 10))
		out.append(_food("Pastel de carne", 9, 12))
		out.append(_food("Açaí 500 ml", 18, 20))
		out.append(_food("Coca-Cola (lata)", 6, 3))
	elif shop_id == "roupas":
		out.append(_shirt("Camisa Seleção Brasileira", 350, Color(0.98, 0.85, 0.1)))
		out.append(_shirt("Camisa Flamengo", 350, Color(0.8, 0.1, 0.1)))
		out.append(_shirt("Camisa Corinthians", 350, Color(0.92, 0.92, 0.92)))
		out.append(_shirt("Camisa Real Madrid", 400, Color(0.95, 0.95, 0.98)))
		out.append(_shirt("Camisa Barcelona", 400, Color(0.5, 0.1, 0.3)))
		out.append(_shirt("Camiseta Nike preta", 180, Color(0.1, 0.1, 0.1)))
		out.append(_shirt("Camiseta Adidas branca", 180, Color(0.95, 0.95, 0.95)))
		out.append(_pants("Calça Levi's 501", 400, Color(0.15, 0.25, 0.5)))
		out.append(_pants("Calça Nike preta", 250, Color(0.08, 0.08, 0.1)))
		out.append(_pants("Bermuda Adidas", 200, Color(0.2, 0.2, 0.25)))
	return out


static func jobs() -> Array:
	return [
		{"id": "entregador_pe", "name": "Entregador (a pé)", "available": true,
			"desc": "Pegue encomendas e entregue nos endereços marcados na cidade. Quanto mais longe, mais você ganha."},
		{"id": "taxista", "name": "Taxista", "available": false, "desc": "Precisa de veículos dirigíveis (próxima etapa)."},
		{"id": "caminhoneiro", "name": "Motorista de caminhão", "available": false, "desc": "Precisa de veículos dirigíveis (próxima etapa)."},
		{"id": "onibus", "name": "Motorista de ônibus", "available": false, "desc": "Precisa de veículos dirigíveis (próxima etapa)."},
		{"id": "policial", "name": "Policial", "available": false, "desc": "Depende do sistema de polícia (etapa futura)."},
		{"id": "mecanico", "name": "Mecânico", "available": false, "desc": "Depende de oficinas e veículos (etapa futura)."},
		{"id": "fazendeiro", "name": "Fazendeiro", "available": false, "desc": "Depende das fazendas jogáveis (etapa futura)."},
	]
