extends Node
# Dinheiro, itens, garagem, roupa e fome do jogador (salvo em user://save.cfg).

signal changed
signal outfit_changed

const SAVE_PATH: String = "user://save.cfg"

var money: int = 1000
var inventory: Dictionary = {}
var garage: Array = []
var shirt: Color = Color(0.15, 0.45, 0.85)
var pants: Color = Color(0.12, 0.14, 0.2)
var hunger: float = 100.0
var deliveries_done: int = 0

var _save_timer: float = 0.0


func _ready() -> void:
	load_data()


func _process(delta: float) -> void:
	hunger = maxf(0.0, hunger - delta * 0.12)
	_save_timer += delta
	if _save_timer > 20.0:
		_save_timer = 0.0
		save_data()


func speed_multiplier() -> float:
	if hunger <= 0.0:
		return 0.7
	return 1.0


func add_money(amount: int) -> void:
	money += amount
	save_data()
	changed.emit()


func buy(item: Dictionary) -> String:
	var price: int = int(item["price"])
	var nm: String = str(item["name"])
	if money < price:
		return "Dinheiro insuficiente para comprar " + nm + "."
	money -= price
	var cat: String = str(item["cat"])
	var msg: String = "Compra feita: " + nm + "."
	if cat == "veiculo":
		garage.append(nm)
		msg = "Você comprou " + nm + "! Ele foi para a sua garagem (dirigir chega na próxima etapa)."
	elif cat == "roupa":
		if item.has("shirt"):
			shirt = item["shirt"] as Color
		if item.has("pants"):
			pants = item["pants"] as Color
		outfit_changed.emit()
		msg = "Você vestiu: " + nm + "."
	elif item.has("food"):
		hunger = minf(100.0, hunger + float(item["food"]))
		msg = "Você consumiu: " + nm + ". A fome diminuiu."
	else:
		inventory[nm] = int(inventory.get(nm, 0)) + 1
		msg = "Você comprou: " + nm + " (guardado no inventário)."
	save_data()
	changed.emit()
	return msg


func summary() -> String:
	var parts: Array = []
	for k in inventory.keys():
		parts.append("%s x%d" % [str(k), int(inventory[k])])
	var inv: String = "nenhum"
	if not parts.is_empty():
		inv = ", ".join(parts)
	var gar: String = "vazia"
	if not garage.is_empty():
		gar = ", ".join(garage)
	return "Garagem: %s\nInventário: %s" % [gar, inv]


func save_data() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("player", "money", money)
	cfg.set_value("player", "garage", garage)
	cfg.set_value("player", "inventory", inventory)
	cfg.set_value("player", "shirt", shirt.to_html(false))
	cfg.set_value("player", "pants", pants.to_html(false))
	cfg.set_value("player", "hunger", hunger)
	cfg.set_value("player", "deliveries", deliveries_done)
	cfg.save(SAVE_PATH)


func load_data() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	money = int(cfg.get_value("player", "money", 1000))
	garage = cfg.get_value("player", "garage", []) as Array
	inventory = cfg.get_value("player", "inventory", {}) as Dictionary
	shirt = Color.html(str(cfg.get_value("player", "shirt", "2673d9")))
	pants = Color.html(str(cfg.get_value("player", "pants", "1f2433")))
	hunger = float(cfg.get_value("player", "hunger", 100.0))
	deliveries_done = int(cfg.get_value("player", "deliveries", 0))
