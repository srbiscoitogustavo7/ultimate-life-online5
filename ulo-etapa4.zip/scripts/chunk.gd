extends Node3D
# Um pedaço do mapa (120 m x 120 m): chão, prédios, árvores, postes, marcos famosos,
# barracas da praça e colisão. Tudo em MultiMesh para gastar poucas chamadas de desenho.

const CityGen = preload("res://scripts/city_gen.gd")
const LandmarksScript = preload("res://scripts/landmarks.gd")
const ShopsData = preload("res://scripts/shops_data.gd")

var cx: int = 0
var cz: int = 0
var district: int = 0
var has_collision: bool = false

var _boxes: Array = []


func build(world, ix: int, iz: int, veg: float, with_collision: bool) -> void:
	cx = ix
	cz = iz
	position = Vector3(float(cx) * CityGen.CHUNK, 0.0, float(cz) * CityGen.CHUNK)
	district = CityGen.district_for(cx, cz)

	var rng := RandomNumberGenerator.new()
	rng.seed = int(CityGen.hash2(cx, cz, 7) * 1000000000.0) + 1

	_build_ground(world)
	var plan: Array = CityGen.plan_buildings(cx, cz, district, rng)
	_build_buildings(world, plan)
	_build_trees(world, CityGen.plan_trees(district, veg, rng))
	if world.street_props:
		_build_lights(world)

	if district == CityGen.D_LANDMARK:
		_build_landmark(world, CityGen.landmark_at(cx, cz))
	elif district == CityGen.D_PLAZA:
		_build_plaza(world)

	if with_collision:
		build_collision()


func _build_ground(world) -> void:
	var mi := MeshInstance3D.new()
	mi.mesh = world.meshes["ground"] as Mesh
	mi.position = Vector3(CityGen.CHUNK * 0.5, 0.0, CityGen.CHUNK * 0.5)
	mi.material_override = world.ground_material(district)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)


func _make_mmi(mesh: Mesh, count: int, use_colors: bool) -> MultiMeshInstance3D:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = use_colors
	mm.mesh = mesh
	mm.instance_count = count
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	return mmi


func _build_buildings(world, plan: Array) -> void:
	if plan.is_empty():
		return

	var mmi := _make_mmi(world.meshes["box"] as Mesh, plan.size(), true)
	mmi.material_override = world.building_mat
	add_child(mmi)
	var mm: MultiMesh = mmi.multimesh

	var roofs: Array = []
	for i in plan.size():
		var b: Dictionary = plan[i]
		var c: Vector3 = b["c"]
		var s: Vector3 = b["s"]
		mm.set_instance_transform(i, Transform3D(Basis.from_scale(s), c))
		mm.set_instance_color(i, b["color"] as Color)
		_boxes.append({"c": c, "s": s})
		if float(b["roof"]) > 0.0:
			roofs.append(b)

	if roofs.is_empty():
		return
	var rmmi := _make_mmi(world.meshes["prism"] as Mesh, roofs.size(), true)
	rmmi.material_override = world.materials["roof"] as Material
	add_child(rmmi)
	var rm: MultiMesh = rmmi.multimesh
	for i in roofs.size():
		var b2: Dictionary = roofs[i]
		var c2: Vector3 = b2["c"]
		var s2: Vector3 = b2["s"]
		var rh: float = float(b2["roof"])
		var pos: Vector3 = Vector3(c2.x, c2.y + s2.y * 0.5 + rh * 0.5, c2.z)
		rm.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3(s2.x + 0.8, rh, s2.z + 0.8)), pos))
		rm.set_instance_color(i, b2["roof_color"] as Color)


func _build_trees(world, trees: Array) -> void:
	if trees.is_empty():
		return

	var trunks := _make_mmi(world.meshes["trunk"] as Mesh, trees.size(), false)
	trunks.material_override = world.materials["trunk"] as Material
	trunks.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(trunks)

	var crowns := _make_mmi(world.meshes["crown"] as Mesh, trees.size(), true)
	crowns.material_override = world.materials["crown"] as Material
	add_child(crowns)

	var tm: MultiMesh = trunks.multimesh
	var cm: MultiMesh = crowns.multimesh
	for i in trees.size():
		var t: Dictionary = trees[i]
		var p: Vector3 = t["p"]
		var h: float = float(t["h"])
		var r: float = float(t["r"])
		var palm: bool = bool(t["palm"])
		tm.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3(1.0, h, 1.0)), Vector3(p.x, h * 0.5, p.z)))
		if palm:
			cm.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3(r * 3.0, r * 0.7, r * 3.0)), Vector3(p.x, h, p.z)))
		else:
			cm.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3(r * 2.0, r * 1.8, r * 2.0)), Vector3(p.x, h + r * 0.6, p.z)))
		cm.set_instance_color(i, t["color"] as Color)


func _build_lights(world) -> void:
	if district == CityGen.D_BEACH or district == CityGen.D_FOREST or district == CityGen.D_PARK:
		return
	var spots: Array = [
		Vector2(10.4, 10.4), Vector2(109.6, 10.4), Vector2(10.4, 109.6), Vector2(109.6, 109.6),
		Vector2(60.0, 10.4), Vector2(60.0, 109.6), Vector2(10.4, 60.0), Vector2(109.6, 60.0),
	]
	var poles := _make_mmi(world.meshes["pole"] as Mesh, spots.size(), false)
	poles.material_override = world.materials["pole"] as Material
	poles.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(poles)
	var lamps := _make_mmi(world.meshes["lamp"] as Mesh, spots.size(), false)
	lamps.material_override = world.materials["lamp"] as Material
	lamps.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(lamps)
	for i in spots.size():
		var s: Vector2 = spots[i]
		poles.multimesh.set_instance_transform(i, Transform3D(Basis.IDENTITY, Vector3(s.x, 4.0, s.y)))
		lamps.multimesh.set_instance_transform(i, Transform3D(Basis.IDENTITY, Vector3(s.x, 8.1, s.y)))


# Marcos famosos: peças agrupadas por tipo (1 chamada de desenho por grupo).
func _build_landmark(world, lname: String) -> void:
	var prims: Array = LandmarksScript.prims(lname)
	var groups: Dictionary = {}
	var emits: Array = []
	for p in prims:
		var d: Dictionary = p
		if bool(d["col"]):
			_boxes.append({"c": d["p"], "s": d["s"], "rot": d["rot"]})
		if bool(d["emit"]):
			emits.append(d)
			continue
		var gk: String = str(d["t"])
		if bool(d["win"]):
			gk += "_win"
		if not groups.has(gk):
			groups[gk] = []
		(groups[gk] as Array).append(d)

	for gk2 in groups.keys():
		var key: String = str(gk2)
		var arr: Array = groups[gk2]
		var is_win: bool = key.ends_with("_win")
		var mesh_type: String = key.replace("_win", "")
		var mmi := _make_mmi(world.meshes[mesh_type] as Mesh, arr.size(), true)
		if is_win:
			mmi.material_override = world.building_mat
		else:
			mmi.material_override = world.materials["roof"] as Material
		add_child(mmi)
		for i in arr.size():
			var d2: Dictionary = arr[i]
			var rot: Vector3 = d2["rot"]
			var tb: Basis = Basis.from_euler(Vector3(deg_to_rad(rot.x), deg_to_rad(rot.y), deg_to_rad(rot.z)))
			tb = tb * Basis.from_scale(d2["s"] as Vector3)
			mmi.multimesh.set_instance_transform(i, Transform3D(tb, d2["p"] as Vector3))
			mmi.multimesh.set_instance_color(i, d2["c"] as Color)

	for e in emits:
		var ed: Dictionary = e
		var mi := MeshInstance3D.new()
		mi.mesh = world.meshes[str(ed["t"])] as Mesh
		mi.material_override = world.emissive_material(ed["c"] as Color)
		var er: Vector3 = ed["rot"]
		var eb: Basis = Basis.from_euler(Vector3(deg_to_rad(er.x), deg_to_rad(er.y), deg_to_rad(er.z)))
		eb = eb * Basis.from_scale(ed["s"] as Vector3)
		mi.transform = Transform3D(eb, ed["p"] as Vector3)
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mi)


func _add_part(world, parent: Node3D, mesh_type: String, pos: Vector3, size: Vector3, color: Color) -> void:
	var mi := MeshInstance3D.new()
	mi.mesh = world.meshes[mesh_type] as Mesh
	mi.material_override = world.flat_material(color)
	mi.position = pos
	mi.scale = size
	parent.add_child(mi)


# Praça central: barracas (lojas e central de empregos) viradas para a fonte.
func _build_plaza(world) -> void:
	for k in ShopsData.kiosks():
		var kd: Dictionary = k
		var pos2: Vector2 = kd["pos"]
		var yaw: float = ShopsData.yaw_for(pos2)
		var col: Color = kd["color"]

		var root := Node3D.new()
		root.position = Vector3(pos2.x, 0.0, pos2.y)
		root.rotation.y = yaw
		add_child(root)

		_add_part(world, root, "box", Vector3(0, 2.5, 0), Vector3(12, 5, 8), col)
		_add_part(world, root, "box", Vector3(0, 4.3, -5.0), Vector3(13, 0.4, 3.5), col.darkened(0.3))
		_add_part(world, root, "box", Vector3(0, 1.8, -4.05), Vector3(7, 3.4, 0.2), Color(0.12, 0.2, 0.3))

		var sign_label := Label3D.new()
		sign_label.text = str(kd["name"])
		sign_label.font_size = 72
		sign_label.pixel_size = 0.012
		sign_label.outline_size = 16
		sign_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		sign_label.position = Vector3(0, 7.2, -4.0)
		root.add_child(sign_label)

		_boxes.append({"c": Vector3(pos2.x, 2.5, pos2.y), "s": Vector3(12, 5, 8), "rot": Vector3(0, rad_to_deg(yaw), 0)})

	# Fonte no centro da praça
	_add_part(world, self, "cyl", Vector3(60, 0.4, 60), Vector3(12, 0.8, 12), Color(0.6, 0.6, 0.62))
	_add_part(world, self, "cyl", Vector3(60, 0.7, 60), Vector3(10.4, 0.2, 10.4), Color(0.2, 0.5, 0.8))
	_add_part(world, self, "cyl", Vector3(60, 2.2, 60), Vector3(1.4, 3.5, 1.4), Color(0.65, 0.65, 0.68))


# Colisão do chão, dos prédios e das barracas (criada só quando o chunk está perto do jogador).
func build_collision() -> void:
	if has_collision:
		return
	has_collision = true

	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0

	var ground := CollisionShape3D.new()
	var gs := BoxShape3D.new()
	gs.size = Vector3(CityGen.CHUNK, 1.0, CityGen.CHUNK)
	ground.shape = gs
	ground.position = Vector3(CityGen.CHUNK * 0.5, -0.5, CityGen.CHUNK * 0.5)
	body.add_child(ground)

	for b in _boxes:
		var d: Dictionary = b
		var shape := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = d["s"] as Vector3
		shape.shape = bs
		shape.position = d["c"] as Vector3
		if d.has("rot"):
			shape.rotation_degrees = d["rot"] as Vector3
		body.add_child(shape)

	add_child(body)
