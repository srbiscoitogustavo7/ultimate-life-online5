extends RefCounted
# Marcos famosos do mundo real, montados com formas simples (escala reduzida).
# Cada peça: t = box/cyl/cone/sphere, p = centro (x, y, z no chunk), s = tamanho,
# win = janelas procedurais, col = colisão, rot = rotação em graus, emit = brilha.


static func _p(t: String, pos: Vector3, size: Vector3, color: Color, win: bool, col: bool, rot: Vector3 = Vector3.ZERO, emit: bool = false) -> Dictionary:
	return {"t": t, "p": pos, "s": size, "c": color, "win": win, "col": col, "rot": rot, "emit": emit}


static func _tier(out: Array, w: float, h: float, d: float, y: float, color: Color, win: bool) -> void:
	out.append(_p("box", Vector3(60.0, y + h * 0.5, 60.0), Vector3(w, h, d), color, win, true))


static func prims(lname: String) -> Array:
	if lname == "empire_state":
		return _empire_state()
	if lname == "burj_khalifa":
		return _burj_khalifa()
	if lname == "eiffel":
		return _eiffel()
	if lname == "big_ben":
		return _big_ben()
	if lname == "cristo":
		return _cristo()
	return []


# Empire State Building (Nova York)
static func _empire_state() -> Array:
	var out: Array = []
	var stone: Color = Color(0.76, 0.74, 0.68)
	_tier(out, 64.0, 28.0, 46.0, 0.0, stone, true)
	_tier(out, 48.0, 22.0, 34.0, 28.0, stone, true)
	_tier(out, 40.0, 70.0, 28.0, 50.0, stone, true)
	_tier(out, 30.0, 30.0, 22.0, 120.0, stone, true)
	_tier(out, 20.0, 20.0, 16.0, 150.0, stone, true)
	_tier(out, 11.0, 14.0, 11.0, 170.0, stone, true)
	out.append(_p("cone", Vector3(60.0, 196.0, 60.0), Vector3(6.0, 24.0, 6.0), Color(0.7, 0.7, 0.72), false, false))
	out.append(_p("cyl", Vector3(60.0, 219.0, 60.0), Vector3(1.2, 22.0, 1.2), Color(0.85, 0.85, 0.88), false, false))
	return out


# Burj Khalifa (Dubai)
static func _burj_khalifa() -> Array:
	var out: Array = []
	var glass: Color = Color(0.62, 0.72, 0.82)
	var widths: Array = [38.0, 34.0, 30.0, 26.0, 22.0, 18.0, 14.0, 10.0]
	var y: float = 0.0
	for w in widths:
		var wf: float = w
		_tier(out, wf, 36.0, wf, y, glass, true)
		out.append(_p("box", Vector3(60.0, y + 18.0, 60.0), Vector3(wf, 36.0, wf), glass, true, false, Vector3(0, 45, 0)))
		y += 36.0
	out.append(_p("cone", Vector3(60.0, y + 15.0, 60.0), Vector3(7.0, 30.0, 7.0), Color(0.8, 0.8, 0.85), false, false))
	out.append(_p("cyl", Vector3(60.0, y + 45.0, 60.0), Vector3(1.0, 30.0, 1.0), Color(0.85, 0.85, 0.9), false, false))
	return out


# Torre Eiffel (Paris)
static func _eiffel() -> Array:
	var out: Array = []
	var iron: Color = Color(0.36, 0.3, 0.24)
	var spreads: Array = [26.0, 20.0, 14.0, 9.0]
	var y: float = 0.0
	for sp in spreads:
		var spf: float = sp
		var post: float = 5.0 - y / 40.0
		for sx in [-1.0, 1.0]:
			for sz in [-1.0, 1.0]:
				out.append(_p("box", Vector3(60.0 + float(sx) * spf, y + 10.0, 60.0 + float(sz) * spf), Vector3(post, 20.0, post), iron, false, y < 20.0))
		y += 20.0
	out.append(_p("box", Vector3(60.0, 18.0, 60.0), Vector3(54.0, 3.0, 54.0), iron, false, false))
	out.append(_p("box", Vector3(60.0, 58.0, 60.0), Vector3(30.0, 3.0, 30.0), iron, false, false))
	for sx2 in [-1.0, 1.0]:
		for sz2 in [-1.0, 1.0]:
			out.append(_p("box", Vector3(60.0 + float(sx2) * 5.0, 95.0, 60.0 + float(sz2) * 5.0), Vector3(3.0, 30.0, 3.0), iron, false, false))
	out.append(_p("box", Vector3(60.0, 110.0, 60.0), Vector3(16.0, 3.0, 16.0), iron, false, false))
	out.append(_p("cone", Vector3(60.0, 125.0, 60.0), Vector3(8.0, 28.0, 8.0), iron, false, false))
	out.append(_p("cyl", Vector3(60.0, 147.0, 60.0), Vector3(0.8, 16.0, 0.8), iron, false, false))
	return out


# Big Ben e Palácio de Westminster (Londres)
static func _big_ben() -> Array:
	var out: Array = []
	var stone: Color = Color(0.72, 0.62, 0.4)
	out.append(_p("box", Vector3(84.0, 26.0, 60.0), Vector3(14.0, 52.0, 14.0), stone, false, true))
	out.append(_p("box", Vector3(84.0, 59.0, 60.0), Vector3(16.0, 14.0, 16.0), stone, false, false))
	out.append(_p("cone", Vector3(84.0, 77.0, 60.0), Vector3(14.0, 22.0, 14.0), Color(0.25, 0.3, 0.3), false, false))
	out.append(_p("cyl", Vector3(84.0, 94.0, 60.0), Vector3(1.0, 12.0, 1.0), Color(0.8, 0.7, 0.3), false, false))
	var face: Color = Color(0.95, 0.92, 0.7)
	out.append(_p("cyl", Vector3(84.0, 59.0, 51.9), Vector3(11.0, 0.8, 11.0), face, false, false, Vector3(90, 0, 0), true))
	out.append(_p("cyl", Vector3(84.0, 59.0, 68.1), Vector3(11.0, 0.8, 11.0), face, false, false, Vector3(90, 0, 0), true))
	out.append(_p("cyl", Vector3(75.9, 59.0, 60.0), Vector3(11.0, 0.8, 11.0), face, false, false, Vector3(0, 0, 90), true))
	out.append(_p("cyl", Vector3(92.1, 59.0, 60.0), Vector3(11.0, 0.8, 11.0), face, false, false, Vector3(0, 0, 90), true))
	out.append(_p("box", Vector3(44.0, 8.0, 60.0), Vector3(64.0, 16.0, 18.0), stone, true, true))
	out.append(_p("box", Vector3(44.0, 18.0, 60.0), Vector3(40.0, 4.0, 12.0), Color(0.3, 0.35, 0.35), false, false))
	return out


# Cristo Redentor (Rio de Janeiro)
static func _cristo() -> Array:
	var out: Array = []
	var white: Color = Color(0.88, 0.9, 0.88)
	out.append(_p("cone", Vector3(60.0, 19.0, 60.0), Vector3(90.0, 38.0, 90.0), Color(0.3, 0.42, 0.28), false, false))
	out.append(_p("box", Vector3(60.0, 44.0, 60.0), Vector3(10.0, 12.0, 10.0), Color(0.7, 0.7, 0.68), false, true))
	out.append(_p("cone", Vector3(60.0, 63.0, 60.0), Vector3(8.0, 26.0, 8.0), white, false, false))
	out.append(_p("box", Vector3(60.0, 70.0, 60.0), Vector3(28.0, 2.2, 2.2), white, false, false))
	out.append(_p("sphere", Vector3(60.0, 78.5, 60.0), Vector3(4.4, 5.0, 4.4), white, false, false))
	return out
