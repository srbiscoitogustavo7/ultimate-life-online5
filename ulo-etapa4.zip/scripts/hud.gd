extends Control
# HUD: hora, FPS, dinheiro, fome, objetivo do trabalho, botão de interação e de configurações.

signal settings_requested
signal interact_requested

var world = null
var economy = null
var jobs = null
var interaction = null

var _info: Label
var _stats: Label
var _objective: Label
var _interact: Button


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

	var top := HBoxContainer.new()
	top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	top.offset_left = 20.0
	top.offset_right = -20.0
	top.offset_top = 12.0
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(top)

	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(left)

	_info = _make_label(24)
	left.add_child(_info)
	_stats = _make_label(26)
	left.add_child(_stats)
	_objective = _make_label(26)
	_objective.add_theme_color_override("font_color", Color(1.0, 0.9, 0.3))
	left.add_child(_objective)

	var btn := Button.new()
	btn.text = "GRÁFICOS"
	btn.custom_minimum_size = Vector2(230, 70)
	btn.add_theme_font_size_override("font_size", 26)
	btn.pressed.connect(_on_settings)
	top.add_child(btn)

	_interact = Button.new()
	_interact.custom_minimum_size = Vector2(340, 90)
	_interact.add_theme_font_size_override("font_size", 28)
	_interact.set_anchors_and_offsets_preset(Control.PRESET_CENTER_RIGHT)
	_interact.offset_left = -360.0
	_interact.offset_right = -20.0
	_interact.offset_top = -45.0
	_interact.offset_bottom = 45.0
	_interact.visible = false
	_interact.pressed.connect(_on_interact)
	add_child(_interact)


func _make_label(size: int) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _on_settings() -> void:
	settings_requested.emit()


func _on_interact() -> void:
	interact_requested.emit()


func _process(_delta: float) -> void:
	var h: float = 0.0
	if world != null:
		h = world.current_hour()
		if GameSettings.time_mode != 0:
			h = GameSettings.time_hour()
	var hh: int = int(floor(h))
	var mm: int = int((h - floor(h)) * 60.0)
	_info.text = "ULTIMATE LIFE ONLINE | %02d:%02d | %d FPS | %s" % [
		hh, mm, int(Engine.get_frames_per_second()), GameSettings.preset_name()
	]

	if economy != null:
		_stats.text = "Dinheiro: R$ %d   |   Fome: %d%%" % [int(economy.money), int(economy.hunger)]

	var obj: String = ""
	if jobs != null:
		obj = str(jobs.objective_text)
		if str(jobs.message) != "":
			if obj != "":
				obj += "\n"
			obj += str(jobs.message)
	_objective.text = obj

	if interaction != null and not interaction.nearest.is_empty():
		_interact.visible = true
		_interact.text = "ENTRAR: " + str(interaction.nearest["name"])
	else:
		_interact.visible = false
