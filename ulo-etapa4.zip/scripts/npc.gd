extends AnimatableBody3D
# Pedestre: anda pelas calçadas da cidade (grade de ruas), atravessa nas faixas,
# para às vezes e espera se o jogador estiver na frente.
# Perto do jogador: corpo humano animado e colisão. Longe: boneco simples (1 peça), sem colisão.

const HumanoidScript = preload("res://scripts/humanoid.gd")
const CityGen = preload("res://scripts/city_gen.gd")

const DETAIL_DISTANCE: float = 45.0
const COLLISION_DISTANCE: float = 30.0

static var _lod_mesh: CapsuleMesh = null

var manager = null

var _human = null
var _lod: MeshInstance3D
var _speed: float = 1.4
var _from: Vector4i = Vector4i.ZERO
var _to: Vector4i = Vector4i.ZERO
var _wait: float = 0.0
var _detail: bool = true
var _collide: bool = true
var _tick: int = 0


static func _get_lod_mesh() -> CapsuleMesh:
	if _lod_mesh == null:
		_lod_mesh = CapsuleMesh.new()
		_lod_mesh.radius = 0.25
		_lod_mesh.height = 1.7
		_lod_mesh.radial_segments = 6
		_lod_mesh.rings = 2
	return _lod_mesh


func setup(mgr) -> void:
	manager = mgr
	var rng: RandomNumberGenerator = mgr.rng

	sync_to_physics = false
	collision_layer = 4
	collision_mask = 0

	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.3
	cap.height = 1.75
	col.shape = cap
	col.position = Vector3(0, 0.88, 0)
	add_child(col)

	var skins: Array = [
		Color(0.96, 0.80, 0.69), Color(0.87, 0.69, 0.53), Color(0.74, 0.55, 0.39),
		Color(0.55, 0.38, 0.26), Color(0.36, 0.24, 0.17)
	]
	var shirts: Array = [
		Color(0.85, 0.2, 0.2), Color(0.2, 0.5, 0.85), Color(0.2, 0.7, 0.4), Color(0.95, 0.8, 0.2),
		Color(0.9, 0.9, 0.9), Color(0.3, 0.3, 0.35), Color(0.6, 0.3, 0.7), Color(0.95, 0.5, 0.15)
	]
	var pants: Array = [
		Color(0.15, 0.25, 0.5), Color(0.1, 0.1, 0.12), Color(0.4, 0.4, 0.42), Color(0.6, 0.5, 0.35)
	]
	var hairs: Array = [
		Color(0.05, 0.04, 0.04), Color(0.2, 0.12, 0.07), Color(0.4, 0.25, 0.12),
		Color(0.85, 0.7, 0.35), Color(0.6, 0.6, 0.6)
	]
	var shirt: Color = _pick(shirts, rng)

	_human = HumanoidScript.new()
	add_child(_human)
	_human.setup(_pick(skins, rng), shirt, _pick(pants, rng), _pick(hairs, rng))

	_lod = MeshInstance3D.new()
	_lod.mesh = _get_lod_mesh()
	_lod.material_override = HumanoidScript._material(shirt)
	_lod.position = Vector3(0, 0.85, 0)
	_lod.visible = false
	add_child(_lod)

	_speed = rng.randf_range(1.1, 1.7)
	_tick = rng.randi() % 3


func _pick(arr: Array, rng: RandomNumberGenerator) -> Color:
	return arr[rng.randi() % arr.size()] as Color


# Coloca o NPC no ponto p, indo do canto "from" para o canto "to".
func place(from_c: Vector4i, to_c: Vector4i, p: Vector3) -> void:
	_from = from_c
	_to = to_c
	position = p
	position.y = 0.0
	_wait = 0.0
	var dir: Vector3 = CityGen.corner_pos(to_c) - p
	dir.y = 0.0
	if dir.length() > 0.01:
		dir = dir.normalized()
		rotation.y = atan2(-dir.x, -dir.z)


func _set_detail(on: bool) -> void:
	if _detail == on:
		return
	_detail = on
	_human.visible = on
	_lod.visible = not on


func _physics_process(delta: float) -> void:
	if manager == null:
		return

	var pp: Vector3 = manager.get_player_position()
	var dx: float = pp.x - position.x
	var dz: float = pp.z - position.z
	var d2: float = dx * dx + dz * dz
	var radius: float = manager.cull_radius()

	# Muito longe: recoloca perto do jogador (a população acompanha quem joga).
	if d2 > radius * radius * 1.5625:
		manager.place_npc(self)
		return

	var vis: bool = d2 < radius * radius
	if visible != vis:
		visible = vis

	var near_detail: bool = d2 < DETAIL_DISTANCE * DETAIL_DISTANCE
	_set_detail(near_detail)

	var want_collide: bool = d2 < COLLISION_DISTANCE * COLLISION_DISTANCE
	if want_collide != _collide:
		_collide = want_collide
		collision_layer = 4 if want_collide else 0

	# Longe do jogador atualiza só 1 a cada 3 ticks (economiza CPU).
	var dt: float = delta
	_tick += 1
	if not near_detail:
		if _tick % 3 != 0:
			return
		dt = delta * 3.0

	var moving_speed: float = 0.0
	if _wait > 0.0:
		_wait -= dt
	else:
		var target: Vector3 = CityGen.corner_pos(_to)
		var to_vec: Vector3 = target - position
		to_vec.y = 0.0
		var dist: float = to_vec.length()
		if dist < 0.3:
			_arrive()
		else:
			var dir: Vector3 = to_vec / dist
			var blocked: bool = false
			if near_detail:
				var to_player: Vector3 = Vector3(dx, 0.0, dz)
				if to_player.length() < 1.6 and to_player.normalized().dot(dir) > 0.4:
					blocked = true
			if blocked:
				_wait = 0.5
			else:
				position += dir * _speed * dt
				moving_speed = _speed
				var target_yaw: float = atan2(-dir.x, -dir.z)
				if near_detail:
					rotation.y = lerp_angle(rotation.y, target_yaw, clampf(8.0 * dt, 0.0, 1.0))
				else:
					rotation.y = target_yaw

	if near_detail:
		_human.animate(delta, moving_speed, false)


func _arrive() -> void:
	var next_c: Vector4i = manager.pick_next(_to, _from)
	_from = _to
	_to = next_c
	if manager.rng.randf() < 0.2:
		_wait = manager.rng.randf_range(1.5, 4.0)
