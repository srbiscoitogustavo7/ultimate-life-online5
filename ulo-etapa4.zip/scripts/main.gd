extends Node3D
# Inicialização segura: cada módulo é carregado com load() e qualquer erro de script
# aparece na tela (em vez de uma tela cinza). Depois mostra o menu e inicia o jogo.

const MODULES: Array = [
	"res://scripts/game_settings.gd",
	"res://scripts/city_gen.gd",
	"res://scripts/landmarks.gd",
	"res://scripts/shops_data.gd",
	"res://scripts/humanoid.gd",
	"res://scripts/economy.gd",
	"res://scripts/chunk.gd",
	"res://scripts/npc.gd",
	"res://scripts/npc_manager.gd",
	"res://scripts/world.gd",
	"res://scripts/touch_controls.gd",
	"res://scripts/player.gd",
	"res://scripts/interaction.gd",
	"res://scripts/job_manager.gd",
	"res://scripts/shop_ui.gd",
	"res://scripts/ui_settings.gd",
	"res://scripts/hud.gd",
	"res://scripts/main_menu.gd",
]

const SPAWN_POINT: Vector3 = Vector3(0, 1.5, 30)

var _ui: CanvasLayer
var _bg: ColorRect
var _status: Label
var _scripts: Dictionary = {}
var _menu = null
var _world = null
var _economy = null
var _jobs = null
var _panel = null
var _settings_ui = null


func _ready() -> void:
	_ui = CanvasLayer.new()
	add_child(_ui)

	_bg = ColorRect.new()
	_bg.color = Color(0.03, 0.04, 0.08)
	_bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	_ui.add_child(_bg)

	_status = Label.new()
	_status.add_theme_font_size_override("font_size", 30)
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status.set_anchors_preset(Control.PRESET_FULL_RECT)
	_status.offset_left = 40.0
	_status.offset_top = 40.0
	_status.offset_right = -40.0
	_status.offset_bottom = -40.0
	_ui.add_child(_status)

	_status.text = "Ultimate Life Online\nIniciando...\nRenderizador: %s\nGPU: %s" % [
		str(ProjectSettings.get_setting("rendering/renderer/rendering_method")),
		RenderingServer.get_video_adapter_name()
	]
	await get_tree().process_frame

	var failed: Array = _load_modules()
	if not failed.is_empty():
		_status.text = "ERRO DE SCRIPT - tire um print desta tela e envie.\n\nArquivos com erro:\n" + "\n".join(failed)
		return
	if get_node_or_null("/root/GameSettings") == null:
		_status.text = "ERRO: as configurações (GameSettings) não carregaram. Tire um print e envie."
		return

	_status.visible = false
	_menu = _make("main_menu")
	_ui.add_child(_menu)
	_menu.play_pressed.connect(_start_game)
	_menu.quit_pressed.connect(_quit)


func _load_modules() -> Array:
	var failed: Array = []
	for path in MODULES:
		var p: String = path
		var scr = load(p)
		if scr == null or not (scr as Script).can_instantiate():
			failed.append(p)
		else:
			_scripts[p] = scr
	return failed


func _make(mod: String):
	var scr: Script = _scripts["res://scripts/%s.gd" % mod]
	return scr.new()


func _quit() -> void:
	get_tree().quit()


func _set_status(t: String) -> void:
	_status.text = t
	_status.visible = true


func _start_game() -> void:
	_menu.queue_free()
	_bg.visible = true
	_set_status("Carregando Ultimate City...\n1/5 Criando o mundo e o mapa")
	await get_tree().process_frame
	await get_tree().process_frame

	_world = _make("world")
	add_child(_world)
	_world.setup(SPAWN_POINT)

	_set_status("Carregando Ultimate City...\n2/5 Criando o personagem")
	await get_tree().process_frame

	_economy = _make("economy")
	add_child(_economy)

	var controls = _make("touch_controls")
	_ui.add_child(controls)

	var player = _make("player")
	player.controls = controls
	player.economy = _economy
	player.position = SPAWN_POINT
	add_child(player)
	_world.set_player(player)
	player.apply_outfit(_economy.shirt, _economy.pants)
	_economy.outfit_changed.connect(_on_outfit.bind(player))

	_set_status("Carregando Ultimate City...\n3/5 Criando pedestres")
	await get_tree().process_frame

	var npcs = _make("npc_manager")
	add_child(npcs)
	npcs.build(player)

	_set_status("Carregando Ultimate City...\n4/5 Lojas e empregos")
	await get_tree().process_frame

	var inter = _make("interaction")
	add_child(inter)
	inter.setup(player)
	inter.activated.connect(_on_activated)

	_jobs = _make("job_manager")
	add_child(_jobs)
	_jobs.setup(player, _economy)

	var hud = _make("hud")
	hud.world = _world
	hud.economy = _economy
	hud.jobs = _jobs
	hud.interaction = inter
	_ui.add_child(hud)
	hud.settings_requested.connect(_open_settings)
	hud.interact_requested.connect(inter.activate)

	_bg.visible = false
	_status.visible = false


func _on_outfit(player) -> void:
	player.apply_outfit(_economy.shirt, _economy.pants)


func _on_activated(entry: Dictionary) -> void:
	if _panel != null:
		return
	_panel = _make("shop_ui")
	_ui.add_child(_panel)
	_panel.setup(entry, _economy, _jobs)
	_panel.closed.connect(_close_panel)
	_panel.job_selected.connect(_on_job_selected)
	_panel.job_stopped.connect(_on_job_stopped)
	get_tree().paused = true


func _on_job_selected(id: String) -> void:
	_jobs.start_job(id)
	_close_panel()


func _on_job_stopped() -> void:
	_jobs.stop_job()
	_close_panel()


func _close_panel() -> void:
	get_tree().paused = false
	if _panel != null:
		_panel.queue_free()
		_panel = null


func _open_settings() -> void:
	if _settings_ui != null:
		return
	_settings_ui = _make("ui_settings")
	_ui.add_child(_settings_ui)
	_settings_ui.closed.connect(_close_settings)
	get_tree().paused = true


func _close_settings() -> void:
	get_tree().paused = false
	if _settings_ui != null:
		_settings_ui.queue_free()
		_settings_ui = null
