# Ultimate Life Online (Godot 4.3)

## Etapa 3.1 (esta versão)
- Correção da tela cinza: renderizador Compatível (o mesmo das etapas 1 e 2) e inicialização
  segura que mostra na tela qualquer erro de script.
- Mapa de 9,6 km x 9,6 km (80 x 80 chunks) + praia + oceano.
  Distritos: centro, comercial, bairros, subúrbios, indústria, parques, florestas e fazendas.
- Marcos famosos (escala reduzida): Empire State Building, Burj Khalifa, Torre Eiffel, Big Ben e Cristo Redentor.
- Praça central com lojas de verdade: concessionária (carros, motos e caminhões reais), celulares,
  supermercado, fast food, roupas e Central de Empregos.
- Economia: dinheiro, fome, inventário, garagem e roupas (a compra muda a roupa do personagem). Salva em user://save.cfg.
- Emprego disponível: Entregador (a pé). Os demais exigem veículos (próxima etapa).
- 8 predefinições gráficas + 13 opções individuais, todas com efeito real.

## Ainda NÃO existe
Dirigir veículos, prédios de hospital/delegacia, aeroporto/porto, polícia, clima, multiplayer, natação.

## Estrutura
scripts/: main (inicialização), world, chunk, city_gen, landmarks, shops_data, economy, interaction,
job_manager, shop_ui, hud, npc, npc_manager, humanoid, player, touch_controls, main_menu, ui_settings,
game_settings (autoload) | shaders/: ground, building, ocean | assets/cover.png
