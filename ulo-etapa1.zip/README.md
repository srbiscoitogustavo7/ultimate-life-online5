# Ultimate Life Online (Godot 4.3)

## Etapa 1 (esta versão)
- Estrutura do projeto (scenes/, scripts/).
- Personagem controlável em 3ª pessoa: andar (joystick), correr (botão), pular (botão),
  câmera por toque (arrastar no lado direito).
- Mundo de teste: céu, sol com sombras, chão, ruas, prédios, rampa e plataformas.
- Também funciona no PC: setas/ESPAÇO/SHIFT e mouse para a câmera.

## Ainda NÃO existe
Cidade completa, veículos, NPCs, polícia, trabalhos, economia, multiplayer, opções de gráficos.

## Abrir no PC
Abra a pasta no Godot 4.3 e aperte F5.

## Gerar APK na nuvem
GitHub Actions (.github/workflows/build.yml): sobe este zip para o repositório e o APK sai em Artifacts.
