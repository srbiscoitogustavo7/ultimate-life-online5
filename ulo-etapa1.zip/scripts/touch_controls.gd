extends Control
# Controles de toque: joystick (esquerda), câmera (arrastar à direita),
# botão PULAR e botão CORRER (segurar). Também aceita teclado/mouse no PC.

var run_held: bool = false

var _jump_flag: bool = false
var _look_accum: Vector2 = Vector2.ZERO
var _touch_move: Vector2 = Vector2.ZERO

var _joy_idx: int = -1
var _joy_origin: Vector2 = Vector2.ZERO
var _run_idx: int = -1
var _jump_idx: int = -1
var _look_idx: int = -1


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _process(_delta: float) -> void:
	queue_redraw()


# ---------- API usada pelo jogador ----------

func get_move() -> Vector2:
	if _joy_idx != -1:
		return _touch_move
	return Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")


func is_running() -> bool:
	return run_held or Input.is_key_pressed(KEY_SHIFT)


func consume_jump() -> bool:
	var j: bool = _jump_flag or Input.is_action_just_pressed("ui_accept")
	_jump_flag = false
	return j


func consume_look() -> Vector2:
	var l: Vector2 = _look_accum
	_look_accum = Vector2.ZERO
	return l


# ---------- layout ----------

func _radius() -> float:
	var s: Vector2 = get_viewport_rect().size
	return minf(s.x, s.y) * 0.13


func _jump_center() -> Vector2:
	var s: Vector2 = get_viewport_rect().size
	var r: float = _radius()
	return Vector2(s.x - r * 1.7, s.y - r * 1.9)


func _run_center() -> Vector2:
	var s: Vector2 = get_viewport_rect().size
	var r: float = _radius()
	return Vector2(s.x - r * 4.0, s.y - r * 1.3)


func _default_joy_center() -> Vector2:
	var s: Vector2 = get_viewport_rect().size
	var r: float = _radius()
	return Vector2(r * 2.0, s.y - r * 2.0)


# ---------- entrada ----------

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed:
			_touch_down(t.index, t.position)
		else:
			_touch_up(t.index)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		_touch_drag(d.index, d.position, d.relative)


func _touch_down(idx: int, pos: Vector2) -> void:
	var s: Vector2 = get_viewport_rect().size
	var r: float = _radius()
	if _jump_idx == -1 and pos.distance_to(_jump_center()) <= r * 1.1:
		_jump_idx = idx
		_jump_flag = true
	elif _run_idx == -1 and pos.distance_to(_run_center()) <= r * 0.95:
		_run_idx = idx
		run_held = true
	elif _joy_idx == -1 and pos.x < s.x * 0.4:
		_joy_idx = idx
		_joy_origin = pos
		_touch_move = Vector2.ZERO
	elif _look_idx == -1:
		_look_idx = idx


func _touch_up(idx: int) -> void:
	if idx == _jump_idx:
		_jump_idx = -1
	elif idx == _run_idx:
		_run_idx = -1
		run_held = false
	elif idx == _joy_idx:
		_joy_idx = -1
		_touch_move = Vector2.ZERO
	elif idx == _look_idx:
		_look_idx = -1


func _touch_drag(idx: int, pos: Vector2, rel: Vector2) -> void:
	if idx == _joy_idx:
		var r: float = _radius()
		var v: Vector2 = ((pos - _joy_origin) / (r * 1.2)).limit_length(1.0)
		if v.length() < 0.1:
			v = Vector2.ZERO
		_touch_move = v
	elif idx == _look_idx:
		_look_accum += rel


# ---------- desenho ----------

func _draw() -> void:
	var r: float = _radius()

	var joy_c: Vector2 = _default_joy_center()
	if _joy_idx != -1:
		joy_c = _joy_origin
	draw_circle(joy_c, r * 1.2, Color(1, 1, 1, 0.10))
	draw_arc(joy_c, r * 1.2, 0.0, TAU, 48, Color(1, 1, 1, 0.45), 3.0)
	var knob: Vector2 = joy_c
	if _joy_idx != -1:
		knob = joy_c + _touch_move * r * 1.2
	draw_circle(knob, r * 0.5, Color(1, 1, 1, 0.45))

	_draw_button(_jump_center(), r * 0.9, "PULAR", _jump_idx != -1)
	_draw_button(_run_center(), r * 0.75, "CORRER", run_held)


func _draw_button(c: Vector2, rad: float, label: String, pressed: bool) -> void:
	var a: float = 0.16
	if pressed:
		a = 0.40
	draw_circle(c, rad, Color(1, 1, 1, a))
	draw_arc(c, rad, 0.0, TAU, 48, Color(1, 1, 1, 0.55), 3.0)
	var font: Font = ThemeDB.fallback_font
	var fs: int = int(rad * 0.42)
	draw_string(font, c + Vector2(-rad, fs * 0.35), label, HORIZONTAL_ALIGNMENT_CENTER, rad * 2.0, fs)
