extends CharacterBody3D
# Personagem controlável em terceira pessoa (andar, correr, pular, câmera por toque).

const WALK_SPEED: float = 4.0
const RUN_SPEED: float = 8.0
const JUMP_VELOCITY: float = 6.5
const GRAVITY: float = 20.0
const LOOK_SENS: float = 0.004

var controls = null
var spawn_point: Vector3 = Vector3(0, 1.5, 12)

var _yaw: float = 0.0
var _pitch: float = -0.3
var _model: Node3D
var _cam_pivot: Node3D


func _ready() -> void:
	collision_layer = 2
	collision_mask = 1

	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.8
	col.shape = cap
	col.position = Vector3(0, 0.9, 0)
	add_child(col)

	_model = Node3D.new()
	add_child(_model)

	var body_mesh := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.35
	cm.height = 1.8
	body_mesh.mesh = cm
	body_mesh.position = Vector3(0, 0.9, 0)
	body_mesh.material_override = _color_material(Color(0.2, 0.45, 0.9))
	_model.add_child(body_mesh)

	# "Nariz" para indicar para onde o personagem está olhando.
	var nose := MeshInstance3D.new()
	var nb := BoxMesh.new()
	nb.size = Vector3(0.22, 0.12, 0.3)
	nose.mesh = nb
	nose.position = Vector3(0, 1.45, -0.35)
	nose.material_override = _color_material(Color(1.0, 0.6, 0.1))
	_model.add_child(nose)

	_cam_pivot = Node3D.new()
	_cam_pivot.position = Vector3(0, 1.5, 0)
	add_child(_cam_pivot)

	var spring := SpringArm3D.new()
	spring.spring_length = 4.5
	spring.margin = 0.3
	spring.collision_mask = 1
	_cam_pivot.add_child(spring)

	var cam := Camera3D.new()
	cam.fov = 70.0
	spring.add_child(cam)

	_apply_camera()


func _physics_process(delta: float) -> void:
	var move: Vector2 = Vector2.ZERO
	var look: Vector2 = Vector2.ZERO
	var running: bool = false
	var jump: bool = false
	if controls != null:
		move = controls.get_move()
		look = controls.consume_look()
		running = controls.is_running()
		jump = controls.consume_jump()

	_yaw -= look.x * LOOK_SENS
	_pitch = clampf(_pitch - look.y * LOOK_SENS, -1.2, 0.4)
	_apply_camera()

	var speed: float = RUN_SPEED if running else WALK_SPEED
	var dir: Vector3 = Basis(Vector3.UP, _yaw) * Vector3(move.x, 0.0, move.y)
	velocity.x = dir.x * speed
	velocity.z = dir.z * speed

	if is_on_floor():
		if jump:
			velocity.y = JUMP_VELOCITY
		else:
			velocity.y = 0.0
	else:
		velocity.y -= GRAVITY * delta

	move_and_slide()

	if dir.length() > 0.1:
		var target: float = atan2(-dir.x, -dir.z)
		_model.rotation.y = lerp_angle(_model.rotation.y, target, clampf(12.0 * delta, 0.0, 1.0))

	if position.y < -30.0:
		position = spawn_point
		velocity = Vector3.ZERO


func _apply_camera() -> void:
	_cam_pivot.rotation = Vector3(_pitch, _yaw, 0.0)


func _color_material(color: Color) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	return mat
