# Ultimate Life Online (Godot 4.3)

## Etapa 3 (esta versão)
- Menu inicial com a capa do jogo (JOGAR / GRÁFICOS / SAIR).
- Mapa gigante gerado proceduralmente: 5,76 km x 5,76 km (48 x 48 chunks de 120 m) + praia + oceano.
  Centro com arranha-céus, comercial, bairros, subúrbios, indústria, parques e florestas.
- Carregamento por regiões (chunks) ao redor do jogador, com neblina escondendo o limite.
- Oceano com ondas, reflexo, espuma e brilho. Ciclo de dia e noite (24 min) com janelas acesas e postes.
- Pedestres que acompanham o jogador pelo mapa (20 a 220), com LOD (humano detalhado perto, boneco simples longe).
- 8 predefinições gráficas (Econômico, Super Baixo, Baixo, Médio, Médio Forte, Alto, Super Alto, Ultra)
  e 13 opções individuais. Todas alteram algo real (resolução, MSAA, FXAA, sombras, distância, bloom,
  reflexos, vegetação, NPCs, janelas, água, detalhe do chão, FPS).

## Ainda NÃO existe
Carros, concessionárias e prédios específicos (hospital, delegacia etc.), montanhas, natação,
colisão das árvores, clima (chuva/neblina), polícia, economia, multiplayer.

## Estrutura
scripts/: main, world, chunk, city_gen, npc, npc_manager, humanoid, player, touch_controls, hud,
main_menu, ui_settings, game_settings (autoload)
shaders/: ground, building, ocean   |   assets/cover.png (capa)
