extends Control
# HUD: FPS, hora do jogo, perfil gráfico e botão de configurações.

signal settings_requested

var world = null

var _info: Label


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

	var top := HBoxContainer.new()
	top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	top.offset_left = 20.0
	top.offset_right = -20.0
	top.offset_top = 12.0
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(top)

	_info = Label.new()
	_info.add_theme_font_size_override("font_size", 24)
	_info.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	_info.add_theme_constant_override("outline_size", 6)
	_info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(_info)

	var btn := Button.new()
	btn.text = "GRÁFICOS"
	btn.custom_minimum_size = Vector2(230, 70)
	btn.add_theme_font_size_override("font_size", 26)
	btn.pressed.connect(_on_settings)
	top.add_child(btn)


func _on_settings() -> void:
	settings_requested.emit()


func _process(_delta: float) -> void:
	var h: float = 0.0
	if world != null:
		h = world.current_hour()
		if GameSettings.time_mode != 0:
			h = GameSettings.time_hour()
	var hh: int = int(floor(h))
	var mm: int = int((h - floor(h)) * 60.0)
	_info.text = "ULTIMATE LIFE ONLINE | %02d:%02d | %d FPS | Gráficos: %s" % [
		hh, mm, int(Engine.get_frames_per_second()), GameSettings.preset_name()
	]
