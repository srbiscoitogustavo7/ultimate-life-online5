extends Node
# Configurações gráficas e de jogo (salvas em user://settings.cfg).
# Cada opção altera algo real no jogo: veja world.gd (gráficos) e npc_manager.gd (NPCs).

signal changed

const SAVE_PATH: String = "user://settings.cfg"

const PRESET_NAMES: Array = [
	"Econômico", "Super Baixo", "Baixo", "Médio",
	"Médio Forte", "Alto", "Super Alto", "Ultra"
]

const PRESETS: Array = [
	{"res_scale": 0.5, "msaa": 0, "fxaa": false, "shadows": 0, "view_chunks": 2, "glow": false, "reflections": 0, "vegetation": 0.0, "npc_count": 20, "windows": false, "water": 0, "ground_detail": false, "max_fps": 30},
	{"res_scale": 0.6, "msaa": 0, "fxaa": false, "shadows": 0, "view_chunks": 2, "glow": false, "reflections": 0, "vegetation": 0.15, "npc_count": 30, "windows": false, "water": 0, "ground_detail": false, "max_fps": 30},
	{"res_scale": 0.7, "msaa": 0, "fxaa": false, "shadows": 1, "view_chunks": 3, "glow": false, "reflections": 0, "vegetation": 0.35, "npc_count": 45, "windows": true, "water": 1, "ground_detail": false, "max_fps": 45},
	{"res_scale": 0.8, "msaa": 0, "fxaa": true, "shadows": 2, "view_chunks": 3, "glow": false, "reflections": 1, "vegetation": 0.6, "npc_count": 70, "windows": true, "water": 1, "ground_detail": true, "max_fps": 60},
	{"res_scale": 0.9, "msaa": 2, "fxaa": true, "shadows": 2, "view_chunks": 4, "glow": true, "reflections": 1, "vegetation": 0.8, "npc_count": 100, "windows": true, "water": 2, "ground_detail": true, "max_fps": 60},
	{"res_scale": 1.0, "msaa": 2, "fxaa": true, "shadows": 3, "view_chunks": 4, "glow": true, "reflections": 2, "vegetation": 1.0, "npc_count": 130, "windows": true, "water": 2, "ground_detail": true, "max_fps": 60},
	{"res_scale": 1.0, "msaa": 4, "fxaa": true, "shadows": 3, "view_chunks": 5, "glow": true, "reflections": 2, "vegetation": 1.3, "npc_count": 170, "windows": true, "water": 3, "ground_detail": true, "max_fps": 90},
	{"res_scale": 1.0, "msaa": 4, "fxaa": true, "shadows": 4, "view_chunks": 6, "glow": true, "reflections": 3, "vegetation": 1.6, "npc_count": 220, "windows": true, "water": 3, "ground_detail": true, "max_fps": 120},
]

const OPTIONS: Array = [
	{"key": "res_scale", "label": "Resolução 3D", "values": [0.5, 0.6, 0.7, 0.8, 0.9, 1.0], "fmt": "pct"},
	{"key": "msaa", "label": "Antisserrilhado (MSAA)", "values": [0, 2, 4], "fmt": "msaa"},
	{"key": "fxaa", "label": "Suavização de bordas (FXAA)", "values": [false, true], "fmt": "onoff"},
	{"key": "shadows", "label": "Sombras", "values": [0, 1, 2, 3, 4], "fmt": "shadow"},
	{"key": "view_chunks", "label": "Distância de visão", "values": [2, 3, 4, 5, 6], "fmt": "view"},
	{"key": "glow", "label": "Brilho (bloom)", "values": [false, true], "fmt": "onoff"},
	{"key": "reflections", "label": "Reflexos do céu", "values": [0, 1, 2, 3], "fmt": "quality"},
	{"key": "vegetation", "label": "Vegetação", "values": [0.0, 0.15, 0.35, 0.6, 0.8, 1.0, 1.3, 1.6], "fmt": "pct"},
	{"key": "npc_count", "label": "Pedestres (NPCs)", "values": [20, 30, 45, 70, 100, 130, 170, 220], "fmt": "int"},
	{"key": "windows", "label": "Janelas e luzes dos prédios", "values": [false, true], "fmt": "onoff"},
	{"key": "water", "label": "Qualidade da água", "values": [0, 1, 2, 3], "fmt": "water"},
	{"key": "ground_detail", "label": "Detalhe do chão", "values": [false, true], "fmt": "onoff"},
	{"key": "max_fps", "label": "Limite de FPS", "values": [30, 45, 60, 90, 120], "fmt": "int"},
]

const TIME_NAMES: Array = [
	"Automática (ciclo)", "Manhã (08:00)", "Tarde (14:00)", "Pôr do sol (18:00)", "Noite (23:00)"
]
const TIME_HOURS: Array = [0.0, 8.0, 14.0, 18.2, 23.0]

var current: Dictionary = {}
var preset_index: int = 3
var time_mode: int = 0


func _ready() -> void:
	_load()


func _load() -> void:
	var cfg := ConfigFile.new()
	var err: int = cfg.load(SAVE_PATH)
	if err != OK:
		var idx: int = 3
		if OS.get_processor_count() <= 4:
			idx = 2
		preset_index = idx
		current = (PRESETS[idx] as Dictionary).duplicate()
		return

	preset_index = int(cfg.get_value("graphics", "preset", 3))
	time_mode = int(cfg.get_value("game", "time_mode", 0))
	var base_idx: int = clampi(preset_index, 0, PRESETS.size() - 1)
	if preset_index == -1:
		base_idx = 3
	current = (PRESETS[base_idx] as Dictionary).duplicate()
	if preset_index == -1:
		for opt in OPTIONS:
			var k: String = (opt as Dictionary)["key"]
			current[k] = cfg.get_value("custom", k, current[k])


func save() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("graphics", "preset", preset_index)
	cfg.set_value("game", "time_mode", time_mode)
	if preset_index == -1:
		for k in current.keys():
			cfg.set_value("custom", str(k), current[k])
	cfg.save(SAVE_PATH)


func preset_name() -> String:
	if preset_index >= 0 and preset_index < PRESET_NAMES.size():
		return PRESET_NAMES[preset_index] as String
	return "Personalizado"


func apply_preset(i: int) -> void:
	preset_index = i
	current = (PRESETS[i] as Dictionary).duplicate()
	save()
	changed.emit()


func set_option(key: String, value) -> void:
	current[key] = value
	preset_index = -1
	save()
	changed.emit()


func cycle_option(key: String, dir: int = 1) -> void:
	for opt in OPTIONS:
		var o: Dictionary = opt
		if o["key"] != key:
			continue
		var values: Array = o["values"]
		var idx: int = _nearest_index(values, current[key])
		idx = (idx + dir + values.size()) % values.size()
		set_option(key, values[idx])
		return


func cycle_time() -> void:
	time_mode = (time_mode + 1) % TIME_NAMES.size()
	save()
	changed.emit()


func time_hour() -> float:
	return float(TIME_HOURS[time_mode])


func _nearest_index(values: Array, v) -> int:
	var best: int = 0
	var best_d: float = 1.0e20
	for i in values.size():
		var d: float = absf(float(values[i]) - float(v))
		if d < best_d:
			best_d = d
			best = i
	return best


func format_value(fmt: String, v) -> String:
	match fmt:
		"pct":
			return "%d%%" % int(round(float(v) * 100.0))
		"onoff":
			if v:
				return "Ligado"
			return "Desligado"
		"msaa":
			if int(v) == 0:
				return "Desligado"
			return "%dx" % int(v)
		"shadow":
			return (["Desligadas", "Baixa", "Média", "Alta", "Ultra"] as Array)[int(v)] as String
		"view":
			return "%d m" % (int(v) * 120)
		"quality":
			return (["Mínimo", "Médio", "Alto", "Máximo"] as Array)[int(v)] as String
		"water":
			return (["Cor simples", "Ondas", "Ondas + reflexo", "Ondas + reflexo + espuma"] as Array)[int(v)] as String
		_:
			return str(v)
