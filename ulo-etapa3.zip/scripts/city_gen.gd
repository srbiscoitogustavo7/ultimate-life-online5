extends RefCounted
# Geração procedural da cidade (determinística por chunk): distritos, prédios e árvores.
# Mapa: 48 x 48 chunks de 120 m (5,76 km x 5,76 km), mais 2 colunas de praia e o mar a leste.

const CHUNK: float = 120.0
const HALF: int = 24
const BEACH_COLS: int = 2
const SEA_X: float = 3120.0   # (HALF + BEACH_COLS) * CHUNK
const WATER_Y: float = -0.35
const SIDEWALK_CENTER: float = 8.5

const D_DOWNTOWN: int = 0
const D_COMMERCIAL: int = 1
const D_RESIDENTIAL: int = 2
const D_SUBURB: int = 3
const D_INDUSTRIAL: int = 4
const D_PARK: int = 5
const D_FOREST: int = 6
const D_BEACH: int = 7


static func hash2(x: int, z: int, salt: int) -> float:
	var h: int = x * 374761393 + z * 668265263 + salt * 1442695041
	h = (h ^ (h >> 13)) * 1274126177
	h = h ^ (h >> 16)
	return float(h & 0xFFFFFF) / 16777216.0


static func chunk_valid(cx: int, cz: int) -> bool:
	return cx >= -HALF and cx < HALF + BEACH_COLS and cz >= -HALF and cz < HALF


static func district_for(cx: int, cz: int) -> int:
	if cx >= HALF:
		return D_BEACH
	var d: float = sqrt(float(cx * cx + cz * cz))
	var r: float = hash2(cx, cz, 1)
	if d < 3.5:
		return D_DOWNTOWN
	if d < 8.0:
		if r < 0.8:
			return D_COMMERCIAL
		return D_PARK
	var field: float = sin(float(cx) * 0.37) * cos(float(cz) * 0.29) + (r - 0.5) * 0.8
	if d < 16.0:
		if field > 0.75:
			return D_PARK
		if field < -0.7:
			return D_INDUSTRIAL
		return D_RESIDENTIAL
	if field > 0.5:
		return D_FOREST
	if field < -0.8:
		return D_INDUSTRIAL
	return D_SUBURB


# Centro (mundo) de um canto de calçada. c = (linha i, linha j, lado x, lado z).
static func corner_pos(c: Vector4i) -> Vector3:
	return Vector3(
		float(c.x) * CHUNK + float(c.z) * SIDEWALK_CENTER,
		0.0,
		float(c.y) * CHUNK + float(c.w) * SIDEWALK_CENTER
	)


static func _lots(n: int) -> Array:
	var res: Array = []
	var size: float = 100.0 / float(n)
	for i in n:
		for j in n:
			res.append(Vector2(10.0 + (float(i) + 0.5) * size, 10.0 + (float(j) + 0.5) * size))
	return res


static func _box(x: float, z: float, w: float, d: float, h: float, color: Color, roof_h: float, roof_color: Color) -> Dictionary:
	return {
		"c": Vector3(x, h * 0.5, z),
		"s": Vector3(w, h, d),
		"color": color,
		"roof": roof_h,
		"roof_color": roof_color,
	}


static func plan_buildings(cx: int, cz: int, district: int, rng: RandomNumberGenerator) -> Array:
	var out: Array = []
	var no_roof: Color = Color(0, 0, 0)

	if district == D_DOWNTOWN:
		var dd: float = sqrt(float(cx * cx + cz * cz))
		for c in _lots(2):
			var lot: Vector2 = c
			var w: float = rng.randf_range(28.0, 44.0)
			var d: float = rng.randf_range(28.0, 44.0)
			var h: float = rng.randf_range(60.0, 110.0) * (1.6 - dd / 3.5 * 0.6)
			var tone: float = rng.randf()
			var col: Color = Color(0.30 + tone * 0.25, 0.42 + tone * 0.25, 0.55 + tone * 0.25)
			out.append(_box(lot.x, lot.y, w, d, h, col, 0.0, no_roof))

	elif district == D_COMMERCIAL:
		for c in _lots(3):
			var lot: Vector2 = c
			if rng.randf() < 0.15:
				continue
			var w: float = rng.randf_range(18.0, 28.0)
			var d: float = rng.randf_range(18.0, 28.0)
			var h: float = rng.randf_range(12.0, 40.0)
			var col: Color = Color.from_hsv(rng.randf(), 0.22, rng.randf_range(0.75, 0.92))
			out.append(_box(lot.x, lot.y, w, d, h, col, 0.0, no_roof))

	elif district == D_RESIDENTIAL:
		for c in _lots(4):
			var lot: Vector2 = c
			var r: float = rng.randf()
			if r < 0.15:
				continue
			var wall: Color = Color.from_hsv(rng.randf_range(0.03, 0.14), rng.randf_range(0.1, 0.35), rng.randf_range(0.75, 0.95))
			var roof_col: Color = Color.from_hsv(rng.randf_range(0.0, 0.08), 0.5, rng.randf_range(0.3, 0.5))
			if r > 0.9:
				out.append(_box(lot.x, lot.y, 20.0, 20.0, rng.randf_range(15.0, 24.0), Color(0.62, 0.6, 0.58), 0.0, no_roof))
			else:
				out.append(_box(lot.x, lot.y, rng.randf_range(10.0, 15.0), rng.randf_range(9.0, 13.0), rng.randf_range(4.5, 6.5), wall, 2.6, roof_col))

	elif district == D_SUBURB:
		for c in _lots(3):
			var lot: Vector2 = c
			if rng.randf() < 0.3:
				continue
			var wall: Color = Color.from_hsv(rng.randf_range(0.03, 0.14), rng.randf_range(0.1, 0.3), rng.randf_range(0.78, 0.95))
			var roof_col: Color = Color.from_hsv(rng.randf_range(0.0, 0.08), 0.5, rng.randf_range(0.3, 0.5))
			out.append(_box(lot.x, lot.y, rng.randf_range(11.0, 14.0), rng.randf_range(9.0, 12.0), rng.randf_range(4.5, 6.5), wall, 2.6, roof_col))

	elif district == D_INDUSTRIAL:
		for c in _lots(2):
			var lot: Vector2 = c
			var tone: float = rng.randf_range(0.4, 0.65)
			var col: Color = Color(tone, tone + 0.03, tone + 0.08)
			out.append(_box(lot.x, lot.y, rng.randf_range(34.0, 44.0), rng.randf_range(28.0, 40.0), rng.randf_range(8.0, 14.0), col, 0.0, no_roof))

	return out


static func _tree(p: Vector3, rng: RandomNumberGenerator, palm: bool) -> Dictionary:
	if palm:
		return {
			"p": p,
			"h": rng.randf_range(6.0, 8.0),
			"r": 2.2,
			"color": Color(0.2, 0.55 + rng.randf() * 0.1, 0.2),
			"palm": true,
		}
	return {
		"p": p,
		"h": rng.randf_range(2.4, 4.0),
		"r": rng.randf_range(1.5, 2.6),
		"color": Color(0.12 + rng.randf() * 0.1, 0.4 + rng.randf() * 0.2, 0.12 + rng.randf() * 0.08),
		"palm": false,
	}


static func plan_trees(district: int, veg: float, rng: RandomNumberGenerator) -> Array:
	var out: Array = []
	if veg <= 0.01:
		return out

	if district == D_PARK or district == D_FOREST or district == D_BEACH:
		var base: int = 35
		if district == D_FOREST:
			base = 70
		elif district == D_BEACH:
			base = 14
		var count: int = int(float(base) * veg)
		for i in count:
			var p: Vector3 = Vector3(rng.randf_range(12.0, 108.0), 0.0, rng.randf_range(12.0, 108.0))
			out.append(_tree(p, rng, district == D_BEACH))

	elif district == D_RESIDENTIAL or district == D_SUBURB or district == D_COMMERCIAL:
		if veg >= 0.3:
			var spacing: float = 24.0
			if veg >= 1.0:
				spacing = 16.0
			var u: float = 14.0
			while u <= 106.0:
				for edge in [11.5, 108.5]:
					var e: float = edge
					out.append(_tree(Vector3(u, 0.0, e), rng, false))
					out.append(_tree(Vector3(e, 0.0, u), rng, false))
				u += spacing

	return out
