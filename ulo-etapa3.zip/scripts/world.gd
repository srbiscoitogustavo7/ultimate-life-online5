extends Node3D
# Mundo: ambiente, ciclo de dia/noite, oceano, limites do mapa e carregamento de chunks.
# Também aplica as configurações gráficas (apply_graphics): cada opção muda algo real.

const CityGen = preload("res://scripts/city_gen.gd")
const ChunkScript = preload("res://scripts/chunk.gd")
const GroundShader = preload("res://shaders/ground.gdshader")
const BuildingShader = preload("res://shaders/building.gdshader")
const OceanShader = preload("res://shaders/ocean.gdshader")

const DAY_REAL_MINUTES: float = 24.0   # um dia inteiro do jogo = 24 minutos

var player = null
var chunks: Dictionary = {}
var meshes: Dictionary = {}
var materials: Dictionary = {}
var building_mat: ShaderMaterial
var hour: float = 17.0

var _ground_materials: Dictionary = {}
var _ocean_mat: ShaderMaterial
var _queue: Array = []
var _center: Vector2i = Vector2i(100000, 100000)
var _view: int = 3
var _veg_applied: float = -1.0
var _sun: DirectionalLight3D
var _moon: DirectionalLight3D
var _env: Environment
var _sky: Sky
var _sky_mat: ProceduralSkyMaterial
var _ocean: MeshInstance3D
var _time_accum: float = 1.0
var _night: float = 0.0
var _windows_on: bool = true


func setup(spawn: Vector3) -> void:
	_create_meshes()
	_create_materials()
	_create_environment()
	_create_ocean()
	_create_borders()
	GameSettings.changed.connect(apply_graphics)
	apply_graphics()
	_update_time()
	_preload_around(spawn)


func set_player(p) -> void:
	player = p
	apply_graphics()


func current_hour() -> float:
	return hour


func ground_material(district: int) -> ShaderMaterial:
	return _ground_materials[district] as ShaderMaterial


# ------------------------------------------------------------------ criação

func _create_meshes() -> void:
	var ground := PlaneMesh.new()
	ground.size = Vector2(CityGen.CHUNK, CityGen.CHUNK)
	meshes["ground"] = ground

	var box := BoxMesh.new()
	box.size = Vector3.ONE
	meshes["box"] = box

	var prism := PrismMesh.new()
	prism.size = Vector3.ONE
	meshes["prism"] = prism

	var trunk := CylinderMesh.new()
	trunk.top_radius = 0.12
	trunk.bottom_radius = 0.18
	trunk.height = 1.0
	trunk.radial_segments = 6
	trunk.rings = 1
	meshes["trunk"] = trunk

	var crown := SphereMesh.new()
	crown.radius = 0.5
	crown.height = 1.0
	crown.radial_segments = 8
	crown.rings = 4
	meshes["crown"] = crown

	var pole := CylinderMesh.new()
	pole.top_radius = 0.05
	pole.bottom_radius = 0.08
	pole.height = 8.0
	pole.radial_segments = 5
	pole.rings = 1
	meshes["pole"] = pole

	var lamp := SphereMesh.new()
	lamp.radius = 0.35
	lamp.height = 0.7
	lamp.radial_segments = 6
	lamp.rings = 3
	meshes["lamp"] = lamp


func _make_ground_mat(color: Color, pattern: float, roads: float) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = GroundShader
	m.set_shader_parameter("interior_color", color)
	m.set_shader_parameter("pattern", pattern)
	m.set_shader_parameter("roads_enabled", roads)
	return m


func _flat_material(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.9
	return m


func _vertex_color_material() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = 0.9
	return m


func _create_materials() -> void:
	building_mat = ShaderMaterial.new()
	building_mat.shader = BuildingShader

	_ground_materials[CityGen.D_DOWNTOWN] = _make_ground_mat(Color(0.45, 0.45, 0.48), 1.0, 1.0)
	_ground_materials[CityGen.D_COMMERCIAL] = _make_ground_mat(Color(0.5, 0.5, 0.5), 1.0, 1.0)
	_ground_materials[CityGen.D_RESIDENTIAL] = _make_ground_mat(Color(0.30, 0.48, 0.25), 0.0, 1.0)
	_ground_materials[CityGen.D_SUBURB] = _make_ground_mat(Color(0.33, 0.50, 0.27), 0.0, 1.0)
	_ground_materials[CityGen.D_INDUSTRIAL] = _make_ground_mat(Color(0.36, 0.36, 0.38), 1.0, 1.0)
	_ground_materials[CityGen.D_PARK] = _make_ground_mat(Color(0.20, 0.50, 0.20), 0.0, 1.0)
	_ground_materials[CityGen.D_FOREST] = _make_ground_mat(Color(0.14, 0.38, 0.15), 0.0, 1.0)
	_ground_materials[CityGen.D_BEACH] = _make_ground_mat(Color(0.85, 0.78, 0.58), 2.0, 0.0)

	materials["trunk"] = _flat_material(Color(0.33, 0.22, 0.12))
	materials["crown"] = _vertex_color_material()
	materials["roof"] = _vertex_color_material()
	materials["pole"] = _flat_material(Color(0.25, 0.25, 0.28))

	var lamp := StandardMaterial3D.new()
	lamp.albedo_color = Color(1.0, 0.95, 0.8)
	lamp.emission_enabled = true
	lamp.emission = Color(1.0, 0.85, 0.5)
	lamp.emission_energy_multiplier = 0.0
	materials["lamp"] = lamp


func _create_environment() -> void:
	_sky_mat = ProceduralSkyMaterial.new()
	_sky = Sky.new()
	_sky.sky_material = _sky_mat

	_env = Environment.new()
	_env.background_mode = Environment.BG_SKY
	_env.sky = _sky
	_env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	_env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	_env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	_env.adjustment_enabled = true
	_env.adjustment_saturation = 1.12
	_env.fog_enabled = true
	_env.fog_sky_affect = 0.6

	var we := WorldEnvironment.new()
	we.environment = _env
	add_child(we)

	_sun = DirectionalLight3D.new()
	add_child(_sun)

	_moon = DirectionalLight3D.new()
	_moon.light_color = Color(0.55, 0.65, 1.0)
	_moon.shadow_enabled = false
	add_child(_moon)


func _create_ocean() -> void:
	_ocean = MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(2400.0, 2400.0)
	pm.subdivide_width = 159
	pm.subdivide_depth = 159
	_ocean.mesh = pm
	_ocean_mat = ShaderMaterial.new()
	_ocean_mat.shader = OceanShader
	_ocean_mat.set_shader_parameter("shore_x", CityGen.SEA_X)
	_ocean.material_override = _ocean_mat
	_ocean.position = Vector3(CityGen.SEA_X, CityGen.WATER_Y, 0.0)
	_ocean.extra_cull_margin = 50.0
	_ocean.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_ocean)


func _wall(center: Vector3, size: Vector3) -> void:
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.position = center
	var shape := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	shape.shape = bs
	body.add_child(shape)
	add_child(body)


# Paredes invisíveis nos limites do mapa (e na beira do mar: nadar fica para uma etapa futura).
func _create_borders() -> void:
	var half: float = float(CityGen.HALF) * CityGen.CHUNK
	var east: float = CityGen.SEA_X - 6.0
	var width: float = east + half + 40.0
	var mid_x: float = (east - half) * 0.5
	_wall(Vector3(-half - 5.0, 50.0, 0.0), Vector3(10.0, 100.0, half * 2.0 + 40.0))
	_wall(Vector3(east + 5.0, 50.0, 0.0), Vector3(10.0, 100.0, half * 2.0 + 40.0))
	_wall(Vector3(mid_x, 50.0, -half - 5.0), Vector3(width, 100.0, 10.0))
	_wall(Vector3(mid_x, 50.0, half + 5.0), Vector3(width, 100.0, 10.0))


# ------------------------------------------------------------------ gráficos

func apply_graphics() -> void:
	if _env == null:
		return
	var s: Dictionary = GameSettings.current
	var vp: Viewport = get_viewport()

	# Resolução 3D, antisserrilhado e limite de FPS
	vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
	vp.scaling_3d_scale = float(s["res_scale"])
	var msaa: int = int(s["msaa"])
	if msaa >= 4:
		vp.msaa_3d = Viewport.MSAA_4X
	elif msaa >= 2:
		vp.msaa_3d = Viewport.MSAA_2X
	else:
		vp.msaa_3d = Viewport.MSAA_DISABLED
	if bool(s["fxaa"]):
		vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA
	else:
		vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_DISABLED
	Engine.max_fps = int(s["max_fps"])

	# Sombras: ligadas/desligadas, tamanho do mapa de sombra, cascatas, alcance e suavidade
	var sh: int = int(s["shadows"])
	_sun.shadow_enabled = sh > 0
	if sh > 0:
		var atlas: Array = [0, 1024, 2048, 4096, 4096]
		var reach: Array = [0.0, 60.0, 90.0, 140.0, 220.0]
		RenderingServer.directional_shadow_atlas_set_size(int(atlas[sh]), true)
		_sun.directional_shadow_max_distance = float(reach[sh])
		if sh == 1:
			_sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
			RenderingServer.directional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_HARD)
		elif sh == 2:
			_sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
			RenderingServer.directional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_SOFT_LOW)
		elif sh == 3:
			_sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
			RenderingServer.directional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_SOFT_MEDIUM)
		else:
			_sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
			RenderingServer.directional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_SOFT_HIGH)

	# Distância de visão: chunks carregados, neblina e plano distante da câmera
	_view = int(s["view_chunks"])
	var dist: float = float(_view) * CityGen.CHUNK
	_env.fog_density = 2.8 / dist
	var cam: Camera3D = get_viewport().get_camera_3d()
	if cam != null:
		cam.far = dist + CityGen.CHUNK * 1.2
	_center = Vector2i(100000, 100000)

	# Brilho (bloom)
	_env.glow_enabled = bool(s["glow"])
	_env.glow_intensity = 0.8
	_env.glow_bloom = 0.05
	_env.glow_hdr_threshold = 1.0

	# Reflexos do céu: resolução do cubemap
	var refl: int = int(s["reflections"])
	if refl <= 0:
		_sky.radiance_size = Sky.RADIANCE_SIZE_32
	elif refl == 1:
		_sky.radiance_size = Sky.RADIANCE_SIZE_128
	elif refl == 2:
		_sky.radiance_size = Sky.RADIANCE_SIZE_256
	else:
		_sky.radiance_size = Sky.RADIANCE_SIZE_512
	if refl >= 2:
		_sky.process_mode = Sky.PROCESS_MODE_INCREMENTAL
	else:
		_sky.process_mode = Sky.PROCESS_MODE_REALTIME

	# Vegetação (recria os chunks se mudou), janelas, água e detalhe do chão
	var veg: float = float(s["vegetation"])
	if absf(veg - _veg_applied) > 0.001:
		_veg_applied = veg
		_reload_chunks()
	_windows_on = bool(s["windows"])
	building_mat.set_shader_parameter("window_detail", 1.0 if _windows_on else 0.0)
	_ocean_mat.set_shader_parameter("quality", float(int(s["water"])))
	var detail: float = 1.0 if bool(s["ground_detail"]) else 0.0
	for key in _ground_materials.keys():
		(_ground_materials[key] as ShaderMaterial).set_shader_parameter("detail", detail)

	_time_accum = 1.0   # força atualizar o horário/céu


func _reload_chunks() -> void:
	for key in chunks.keys():
		(chunks[key] as Node).queue_free()
	chunks.clear()
	_queue.clear()
	_center = Vector2i(100000, 100000)


# ------------------------------------------------------------------ dia e noite

func _current_hour() -> float:
	if GameSettings.time_mode == 0:
		return hour
	return GameSettings.time_hour()


func _update_time() -> void:
	var h: float = _current_hour()
	var elev: float = sin((h - 6.0) / 24.0 * TAU) * 80.0
	var day_factor: float = smoothstep(-4.0, 14.0, elev)
	var sunset: float = clampf(1.0 - absf(elev - 2.0) / 16.0, 0.0, 1.0)
	_night = 1.0 - smoothstep(-10.0, 4.0, elev)

	_sun.rotation_degrees = Vector3(-elev, 35.0, 0.0)
	_sun.light_energy = smoothstep(-2.0, 12.0, elev) * 1.15
	_sun.light_color = Color(1.0, 0.95, 0.85).lerp(Color(1.0, 0.6, 0.35), sunset * 0.8)
	_sun.visible = elev > -3.0

	_moon.rotation_degrees = Vector3(elev, 215.0, 0.0)
	_moon.light_energy = clampf(-elev / 20.0, 0.0, 1.0) * 0.22
	_moon.visible = elev < 2.0

	var top: Color = Color(0.01, 0.02, 0.07).lerp(Color(0.22, 0.46, 0.88), day_factor)
	var horizon: Color = Color(0.03, 0.05, 0.1).lerp(Color(0.66, 0.78, 0.94), day_factor)
	horizon = horizon.lerp(Color(1.0, 0.55, 0.28), sunset * 0.85)
	_sky_mat.sky_top_color = top
	_sky_mat.sky_horizon_color = horizon
	_sky_mat.ground_horizon_color = horizon
	_sky_mat.ground_bottom_color = top.darkened(0.5)
	_env.fog_light_color = horizon
	_env.ambient_light_energy = lerpf(0.3, 1.0, day_factor)

	var window_night: float = 0.0
	if _windows_on:
		window_night = _night
	building_mat.set_shader_parameter("night", window_night)
	_ocean_mat.set_shader_parameter("night", _night)
	(materials["lamp"] as StandardMaterial3D).emission_energy_multiplier = _night * 3.0


# ------------------------------------------------------------------ chunks

func _dist2(a: Vector2i, b: Vector2i) -> int:
	var dx: int = a.x - b.x
	var dy: int = a.y - b.y
	return dx * dx + dy * dy


func _make_chunk(key: Vector2i, center: Vector2i) -> void:
	var c = ChunkScript.new()
	add_child(c)
	var near: bool = maxi(absi(key.x - center.x), absi(key.y - center.y)) <= 2
	c.build(self, key.x, key.y, _veg_applied, near)
	chunks[key] = c


func _preload_around(spawn: Vector3) -> void:
	var center := Vector2i(int(floor(spawn.x / CityGen.CHUNK)), int(floor(spawn.z / CityGen.CHUNK)))
	for dx in range(-2, 3):
		for dz in range(-2, 3):
			var key := Vector2i(center.x + dx, center.y + dz)
			if CityGen.chunk_valid(key.x, key.y) and not chunks.has(key):
				_make_chunk(key, center)


func _update_streaming() -> void:
	var pp: Vector3 = player.global_position
	var center := Vector2i(int(floor(pp.x / CityGen.CHUNK)), int(floor(pp.z / CityGen.CHUNK)))
	if center == _center:
		return
	_center = center

	for key in chunks.keys():
		var k: Vector2i = key
		if maxi(absi(k.x - center.x), absi(k.y - center.y)) > _view + 1:
			(chunks[k] as Node).queue_free()
			chunks.erase(k)

	var missing: Array = []
	for dx in range(-_view, _view + 1):
		for dz in range(-_view, _view + 1):
			var cand := Vector2i(center.x + dx, center.y + dz)
			if CityGen.chunk_valid(cand.x, cand.y) and not chunks.has(cand):
				missing.append(cand)
	missing.sort_custom(func(a, b): return _dist2(a, center) < _dist2(b, center))
	_queue = missing

	for key2 in chunks.keys():
		var k2: Vector2i = key2
		if maxi(absi(k2.x - center.x), absi(k2.y - center.y)) <= 2:
			chunks[k2].build_collision()


func _process(delta: float) -> void:
	if player == null:
		return

	_update_streaming()
	var t0: int = Time.get_ticks_usec()
	while not _queue.is_empty() and Time.get_ticks_usec() - t0 < 3500:
		var key: Vector2i = _queue.pop_front()
		if not chunks.has(key):
			_make_chunk(key, _center)

	hour += delta * 24.0 / (DAY_REAL_MINUTES * 60.0)
	if hour >= 24.0:
		hour -= 24.0
	_time_accum += delta
	if _time_accum > 0.25:
		_time_accum = 0.0
		_update_time()

	# O oceano acompanha o jogador (a posição das ondas é calculada no mundo, sem "deslizar").
	var pp: Vector3 = player.global_position
	_ocean.position.x = snappedf(pp.x, 15.0)
	_ocean.position.z = snappedf(pp.z, 15.0)
