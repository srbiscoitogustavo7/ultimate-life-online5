extends Node3D
# Um pedaço do mapa (120 m x 120 m): chão, prédios, árvores, postes e colisão.
# Tudo em MultiMesh para gastar poucas chamadas de desenho.

const CityGen = preload("res://scripts/city_gen.gd")

var cx: int = 0
var cz: int = 0
var district: int = 0
var has_collision: bool = false

var _boxes: Array = []


func build(world, ix: int, iz: int, veg: float, with_collision: bool) -> void:
	cx = ix
	cz = iz
	position = Vector3(float(cx) * CityGen.CHUNK, 0.0, float(cz) * CityGen.CHUNK)
	district = CityGen.district_for(cx, cz)

	var rng := RandomNumberGenerator.new()
	rng.seed = int(CityGen.hash2(cx, cz, 7) * 1000000000.0) + 1

	_build_ground(world)
	var plan: Array = CityGen.plan_buildings(cx, cz, district, rng)
	_build_buildings(world, plan)
	_build_trees(world, CityGen.plan_trees(district, veg, rng))
	_build_lights(world)

	if with_collision:
		build_collision()


func _build_ground(world) -> void:
	var mi := MeshInstance3D.new()
	mi.mesh = world.meshes["ground"] as Mesh
	mi.position = Vector3(CityGen.CHUNK * 0.5, 0.0, CityGen.CHUNK * 0.5)
	mi.material_override = world.ground_material(district)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)


func _make_mmi(mesh: Mesh, count: int, use_colors: bool) -> MultiMeshInstance3D:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = use_colors
	mm.mesh = mesh
	mm.instance_count = count
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	return mmi


func _build_buildings(world, plan: Array) -> void:
	if plan.is_empty():
		return

	var mmi := _make_mmi(world.meshes["box"] as Mesh, plan.size(), true)
	mmi.material_override = world.building_mat
	add_child(mmi)
	var mm: MultiMesh = mmi.multimesh

	var roofs: Array = []
	for i in plan.size():
		var b: Dictionary = plan[i]
		var c: Vector3 = b["c"]
		var s: Vector3 = b["s"]
		mm.set_instance_transform(i, Transform3D(Basis.from_scale(s), c))
		mm.set_instance_color(i, b["color"] as Color)
		_boxes.append({"c": c, "s": s})
		if float(b["roof"]) > 0.0:
			roofs.append(b)

	if roofs.is_empty():
		return
	var rmmi := _make_mmi(world.meshes["prism"] as Mesh, roofs.size(), true)
	rmmi.material_override = world.materials["roof"] as Material
	add_child(rmmi)
	var rm: MultiMesh = rmmi.multimesh
	for i in roofs.size():
		var b2: Dictionary = roofs[i]
		var c2: Vector3 = b2["c"]
		var s2: Vector3 = b2["s"]
		var rh: float = float(b2["roof"])
		var pos: Vector3 = Vector3(c2.x, c2.y + s2.y * 0.5 + rh * 0.5, c2.z)
		rm.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3(s2.x + 0.8, rh, s2.z + 0.8)), pos))
		rm.set_instance_color(i, b2["roof_color"] as Color)


func _build_trees(world, trees: Array) -> void:
	if trees.is_empty():
		return

	var trunks := _make_mmi(world.meshes["trunk"] as Mesh, trees.size(), false)
	trunks.material_override = world.materials["trunk"] as Material
	trunks.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(trunks)

	var crowns := _make_mmi(world.meshes["crown"] as Mesh, trees.size(), true)
	crowns.material_override = world.materials["crown"] as Material
	add_child(crowns)

	var tm: MultiMesh = trunks.multimesh
	var cm: MultiMesh = crowns.multimesh
	for i in trees.size():
		var t: Dictionary = trees[i]
		var p: Vector3 = t["p"]
		var h: float = float(t["h"])
		var r: float = float(t["r"])
		var palm: bool = bool(t["palm"])
		tm.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3(1.0, h, 1.0)), Vector3(p.x, h * 0.5, p.z)))
		if palm:
			cm.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3(r * 3.0, r * 0.7, r * 3.0)), Vector3(p.x, h, p.z)))
		else:
			cm.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3(r * 2.0, r * 1.8, r * 2.0)), Vector3(p.x, h + r * 0.6, p.z)))
		cm.set_instance_color(i, t["color"] as Color)


func _build_lights(world) -> void:
	if district == CityGen.D_BEACH or district == CityGen.D_FOREST or district == CityGen.D_PARK:
		return
	var spots: Array = [
		Vector2(10.4, 10.4), Vector2(109.6, 10.4), Vector2(10.4, 109.6), Vector2(109.6, 109.6),
		Vector2(60.0, 10.4), Vector2(60.0, 109.6), Vector2(10.4, 60.0), Vector2(109.6, 60.0),
	]
	var poles := _make_mmi(world.meshes["pole"] as Mesh, spots.size(), false)
	poles.material_override = world.materials["pole"] as Material
	poles.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(poles)
	var lamps := _make_mmi(world.meshes["lamp"] as Mesh, spots.size(), false)
	lamps.material_override = world.materials["lamp"] as Material
	lamps.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(lamps)
	for i in spots.size():
		var s: Vector2 = spots[i]
		poles.multimesh.set_instance_transform(i, Transform3D(Basis.IDENTITY, Vector3(s.x, 4.0, s.y)))
		lamps.multimesh.set_instance_transform(i, Transform3D(Basis.IDENTITY, Vector3(s.x, 8.1, s.y)))


# Colisão do chão e dos prédios (criada só quando o chunk está perto do jogador).
func build_collision() -> void:
	if has_collision:
		return
	has_collision = true

	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0

	var ground := CollisionShape3D.new()
	var gs := BoxShape3D.new()
	gs.size = Vector3(CityGen.CHUNK, 1.0, CityGen.CHUNK)
	ground.shape = gs
	ground.position = Vector3(CityGen.CHUNK * 0.5, -0.5, CityGen.CHUNK * 0.5)
	body.add_child(ground)

	for b in _boxes:
		var d: Dictionary = b
		var shape := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = d["s"] as Vector3
		shape.shape = bs
		shape.position = d["c"] as Vector3
		body.add_child(shape)

	add_child(body)
