extends Node3D
# Raiz do jogo: menu inicial (capa) -> carrega o mundo -> jogador, controles, NPCs e HUD.

const WorldScript = preload("res://scripts/world.gd")
const PlayerScript = preload("res://scripts/player.gd")
const TouchControlsScript = preload("res://scripts/touch_controls.gd")
const NpcManagerScript = preload("res://scripts/npc_manager.gd")
const MenuScript = preload("res://scripts/main_menu.gd")
const HudScript = preload("res://scripts/hud.gd")
const SettingsUIScript = preload("res://scripts/ui_settings.gd")

const SPAWN_POINT: Vector3 = Vector3(0, 1.5, 30)

var _ui: CanvasLayer
var _menu = null
var _world = null
var _settings_ui = null


func _ready() -> void:
	_ui = CanvasLayer.new()
	add_child(_ui)

	_menu = MenuScript.new()
	_ui.add_child(_menu)
	_menu.play_pressed.connect(_start_game)
	_menu.quit_pressed.connect(_quit)


func _quit() -> void:
	get_tree().quit()


func _start_game() -> void:
	_menu.queue_free()

	var loading := Label.new()
	loading.text = "Carregando Ultimate City..."
	loading.add_theme_font_size_override("font_size", 40)
	loading.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_ui.add_child(loading)

	# Deixa o texto aparecer antes da geração inicial do mapa.
	await get_tree().process_frame
	await get_tree().process_frame

	_world = WorldScript.new()
	add_child(_world)
	_world.setup(SPAWN_POINT)

	var controls = TouchControlsScript.new()
	_ui.add_child(controls)

	var player = PlayerScript.new()
	player.controls = controls
	player.position = SPAWN_POINT
	add_child(player)
	_world.set_player(player)

	var npcs = NpcManagerScript.new()
	add_child(npcs)
	npcs.build(player)

	var hud = HudScript.new()
	hud.world = _world
	_ui.add_child(hud)
	hud.settings_requested.connect(_open_settings)

	loading.queue_free()


func _open_settings() -> void:
	if _settings_ui != null:
		return
	_settings_ui = SettingsUIScript.new()
	_ui.add_child(_settings_ui)
	_settings_ui.closed.connect(_close_settings)
	get_tree().paused = true


func _close_settings() -> void:
	get_tree().paused = false
	if _settings_ui != null:
		_settings_ui.queue_free()
		_settings_ui = null
